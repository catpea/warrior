The Greatest minds of our generation, looked back, learned, and brought the
waning wisdom back.