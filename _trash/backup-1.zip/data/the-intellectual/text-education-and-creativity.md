Learning is Unavoidable. Here is [Sir Ken Robinson][1] warning you that
things are not as they should be.

[1]: https://www.youtube.com/results?search_query=Sir+Ken+Robinson