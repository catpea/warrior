To those of you who retain some remnant of dignity and the will to live
your lives for yourselves, you have the chance to make the same choice.
Examine your values and understand that you must choose one side or the
other. Any compromise between good and evil only hurts the good and helps
the evil.

If you've understood what I've said, stop supporting your destroyers.

Don't accept their philosophy.

Your destroyers hold you by means of your endurance, your generosity, your
innocence, and your love.

Don't exhaust yourself to help build the kind of world that you see around
you now.

In the name of the best within you, don't sacrifice the world to those who
will take away your happiness for it.