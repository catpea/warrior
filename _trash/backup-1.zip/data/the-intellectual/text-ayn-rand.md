One particularly magnificent being to go back and learn, and rise, and
triumph is Ayn Rand.