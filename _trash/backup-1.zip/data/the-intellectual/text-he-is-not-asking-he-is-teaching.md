Sir Ken Robinson is clearly well educated and experienced. In preparation
for this talk he would have wanted to come up with a powerful message, an
idea worth sharing. While extraordinary claims, require extraordinary
evidence; a simple question begs a simple answer.

Yes. Schools kill creativity.