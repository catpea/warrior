The battle is for those that come; after you.

In short term, you get a sweet sliver of solace as you learn that in the
end all your troubles ended up counting towards protecting others from the
same.

In long term, you help the world grow, it won't be your world, it will be
the world of the future.

The battle for real education, and enjoying the fruits of real education
are two separate things.

It will make you tired.