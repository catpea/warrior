[YouTube][1] · [Wikipedia][2] · [Audible][3]

[1]: https://www.youtube.com/results?search_query=What+If%3F%3A+Serious+Scientific+Answers+to+Absurd+Hypothetical+Questions
[2]: https://en.wikipedia.org/wiki/What_If%3F:_Serious_Scientific_Answers_to_Absurd_Hypothetical_Questions
[3]: https://www.audible.com/pd/What-If-Audiobook/B00LV6V4UW