There are very few Alternate Education resources, and as you rise you
realize that the Start-up Accelerator rates are extremely low, almost too
low.

Nothing, nothing is as sweet and easy as putting up with broken education,
the broken rules, the status quo, staying in school, getting some "good"
grades, making your parents happy.

Nothing is as easy as forgetting all of that ever happened, and make up
excuses after excuses, forgetting everyone and everything, and never
looking back.

Alas, Dear Henry comes to our rescue.