The first and foremost, you must Retain Your Dignity, and your Nobility.

No one is to treat you as means to their end, to their paycheck, or
vacation, or else.

You are not to be silenced, you are not to go quietly into the night, you
are to rage, to rage against the dying of the light.