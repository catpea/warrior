Real Education, is not about getting really educated.

It is about Your Life, Dignity, Authenticity, Health.

Life that revolves around sweet and easy and making everyone else happy is
not a healthy life.