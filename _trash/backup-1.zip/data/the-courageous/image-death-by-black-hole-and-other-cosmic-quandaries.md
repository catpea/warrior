[YouTube][1] · [Wikipedia][2] · [Audible][3]

[1]: https://www.youtube.com/results?search_query=Death+by+Black+Hole%3A+And+Other+Cosmic+Quandaries
[2]: https://en.wikipedia.org/wiki/Death_by_Black_Hole
[3]: https://www.audible.com/pd/Death-by-Black-Hole-Audiobook/B002VA9L7A