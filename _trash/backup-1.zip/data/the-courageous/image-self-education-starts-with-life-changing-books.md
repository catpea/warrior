Best way to understand a book, is to listen to the Author reading it. And
the best way to listen to a book, is while climbing a [great mountain][1].

[1]: https://en.wikipedia.org/wiki/Mount_Katahdin