The best tool to refine your vision is [Mind Mapping][1]. Visit [List of
concept and mind-mapping software][2] for more.

Visit [Cmap Homepage][3] at Florida Institute for Human & Machine Cognition
(IHMC) for a free download.

[1]: https://en.wikipedia.org/wiki/Mind_map
[2]: https://en.wikipedia.org/wiki/List_of_concept-_and_mind-mapping_software
[3]: https://cmap.ihmc.us/