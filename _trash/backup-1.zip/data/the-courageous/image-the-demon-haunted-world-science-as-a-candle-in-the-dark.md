[YouTube][1] · [Wikipedia][2] · [Audible][3]

[1]: https://www.youtube.com/results?search_query=The+Demon-Haunted+World%3A+Science+as+a+Candle+in+the+Dark
[2]: https://en.wikipedia.org/wiki/The_Demon-Haunted_World
[3]: https://www.audible.com/pd/The-Demon-Haunted-World-Audiobook/B06XTZZLZ8