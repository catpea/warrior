[YouTube][1] · [Wikipedia][2] · [Audible][3]

[1]: https://www.youtube.com/results?search_query=A+Short+History+of+Nearly+Everything
[2]: https://en.wikipedia.org/wiki/A_Short_History_of_Nearly_Everything
[3]: https://www.audible.com/pd/A-Short-History-of-Nearly-Everything-Audiobook/B002V0KFPW