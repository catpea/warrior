[YouTube][1] · [Wikipedia][2] · [Audible][3]

[1]: https://www.youtube.com/results?search_query=The+Physics+of+Superheroes%2C+James+Kakalios
[2]: https://en.wikipedia.org/wiki/The_Physics_of_Superheroes
[3]: https://www.audible.com/pd/The-Physics-of-Superheroes-Audiobook/1684574560