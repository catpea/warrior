Shopify’s Director of Production Engineering explains how reading broadly
helps him get to the bottom of things: [How to Make Yourself Into a
Learning Machine][1]

[Readwise][2] Get the most out of what you read, Readwise makes it easy to revisit and learn from your ebook & article highlights.

[Anki][3] Powerful, intelligent flash cards. Remembering things just became much easier.

[1]: https://superorganizers.substack.com/p/how-to-build-a-learning-machine
[2]: https://readwise.io/
[3]: https://apps.ankiweb.net/