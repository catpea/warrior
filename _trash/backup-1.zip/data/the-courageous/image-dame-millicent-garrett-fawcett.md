English political leader, activist, writer and feminist icon. Known as a
campaigner for women's suffrage via legislative change, from 1897 until
1919 she led Britain's largest women's rights organisation, the National
Union of Women's Suffrage Societies.