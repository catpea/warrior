Relative to their beginnings, many will find just enough comfort and stop,
and often block traffic.

If you rise in class. Your teachers will fight you, because they just want
to do their job, go home, and get paid.

If you rise in class. They will say you are disrupting the class and throw
you out, because they just want you to shut up so they can finish their job
and go watch some TV.

You can talk to the Principal or Dean, but they'll just tag you as "Gifted"
and you'll graduate from Adult Ed so fast you'll struggle to remember where
it all started and what the battle was for.