The best programming language for Leaders, is English. In BDD context, a
structured subset of English.

You can write you entire program in BDD, and coordinate your team at the
same time.

In the world of computers, teams can be distributed across the entire
world. Some teams, can have revolving doors. And sometimes you may not even
need doors, as you can post a BDD Test Issue on [Bounty Source][1] or
similar.

[1]: https://www.bountysource.com/