_The heaviest burden: What, if some day or night, a demon were to steal
after you into your loneliest loneliness and say to you:_

_This life, as you now live it and have lived it, you will have to live
once more and innumerable times more; and there will be nothing new in it,
but every pain and every joy and every thought and sigh… must return to
you—all in the same succession and sequence—even this spider and this
moonlight between the trees and even this moment and I myself. The eternal
hourglass of existence is turned over again and again—and you with it,
speck of dust!_

_Would you not throw yourself down and gnash your teeth and curse the demon
who spoke thus? Or have you once experienced a tremendous moment when you
would have answered him: “You are a god, and never have I heard anything
more divine!”_

_If this thought were to gain possession of you, it would change you as you
are, or perhaps crush you. The question in each and every thing, “do you
want this once more and innumerable times more?” would lie upon your
actions as the greatest weight._