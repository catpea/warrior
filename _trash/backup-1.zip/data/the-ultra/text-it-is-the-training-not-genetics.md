Dean Karnazes, mentions Lactic Acid build up. I think of it as mostly
nonsense, where does the lactic acid go when your performance increases
from long distance running? Your first mile the first time you run will
burn, but the 10,000th time you will feel elation. Genetics are a myth.

Here is Dean’s book, it is a good read, and a good Audiobook. It contains
growing up, and adventures, and stories of triumph, and aches.
[Ultramarathon Man][1]

[1]: https://www.audible.com/pd/Ultramarathon-Man-Audiobook/B002VA3GIU