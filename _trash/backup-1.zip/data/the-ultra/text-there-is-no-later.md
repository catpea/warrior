It is when you stop, and all time scrolls by you, that really hurts. This
is why I write to the youngest of you, one of the greatest Storytellers of
all generations once discovered a great wish that we all wish for
eventually.