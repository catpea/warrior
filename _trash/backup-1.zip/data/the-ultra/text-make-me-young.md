“Make me young again” - but you are young now, you can make most of it, no
wax, because it is all ahead of you. Go, close your eyes and connect with
your 80 year old self, and make the wish Killgore Trout did: “Make Me Young
Again”, and open your eyes, and be young but wiser for it. Therein you will
discover the nature of the Ultra. While we live our only life, poetically
we live as it was countless lives already. By wiggling forward and back we
can see where we are headed, and end up where we always wished to be.