[Friedrich Nietzsche][1] is asking you to review your decisions, treat them with more gravity, “Would you be willing to relive your life again, and again, and again? Or would you prefer to stay dead and if so, then you need to review your decision making.”:

[1]: https://en.wikipedia.org/wiki/Friedrich_Nietzsche