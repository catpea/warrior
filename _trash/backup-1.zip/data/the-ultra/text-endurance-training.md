Bruce Lee, was the first Ultra that I have heard of. Ultras are folks like
you and I that train to jump a little seedling of corn. Day by day,
GRADUALLY, the little corn grows a little bit taller, and the little ultra
strives to jump a little bit higher.

In modern times the C25K comes to mind, meet [Fierce Carli][1] Just from
plain experience with jogging we can guesstimate that by GRADUALLY
increasing the length of distance, we will gain the endurance to run
hundreds of miles.

[1]: http://carlifierce.com/10-k-downloads/