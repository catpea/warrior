The workout is powered by the soul of a very old warrior, who lived many a
lifetime in daydreams, stories, books, and poems. There is no pain, it is
just a signal.

On the Mind part, focus on gaining wisdom by all means. On the body part,
keep extending your endurance, the pain is too primitive to catch up with
an ultra.