Pain, is just a chemical signal, it is a squirt of goo – pain my dear
friends, does not hurt.