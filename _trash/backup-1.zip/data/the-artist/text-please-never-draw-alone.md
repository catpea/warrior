If you are going to draw with pencils make sure to use blending stumps and
smudge the graphite to give it a photo-realistic look. Get an [art
board][1], Drawing Paper (not Sketching Paper), [tin of pencils][2],
battery powered eraser and eraser shield, and head for the [DIA][3], or a
Museum, or even a Coffee Shop.

[1]: https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Darts-crafts&field-keywords=Sketch+Tote+Drawing+
[2]: https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Doffice-products&field-keywords=Staedtler+Lumograph+Graphite+Drawing
[3]: https://www.dia.org/