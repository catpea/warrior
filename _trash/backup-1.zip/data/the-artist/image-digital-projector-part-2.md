You can take a selfie, connect your phone to the projector, and begin
painting.

Even better you can connect your Raspberry PI, or Laptop and use a program
like [GIMP][1] where you can manipulate your source material to reveal
edges, colors, or adjust contrast while painting to reveal the brightest
parts of your source material.

Tip: Consider putting registration marks in your image and on your canvas,
it is easier to resume your work after you bump the projector or call it a
night.

Idea: Record your painting progress and upload a sped up movie to YouTube.

[1]: https://www.gimp.org/