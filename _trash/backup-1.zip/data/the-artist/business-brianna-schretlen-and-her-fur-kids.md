"I'm a professional graphic designer and illustrator with a soft spot for
fur kids. I've always loved painting and drawing animals. Our pets are like
family, and I truly enjoy working on tributes to these silly, lovable,
trusting and loyal creatures. In addition to Bri Pet Portraits, I am also
on Etsy under the shop Bri Baby Art - a shop featuring custom artworks for
nurseries and kids room decor." (from [BriPetPortraits on Etsy][1])

Custom Pet Portraits. Online business where people upload an image, and you
create a large canvas painting, or drawing. It looks like the price is
about $50 per portrait. Throw in a bonus, record a time lapse video of the
painting for advertising, portfolio, and internet points.

[1]: https://www.etsy.com/shop/BriPetPortraits