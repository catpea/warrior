Lightbox will help you with tracing and creation of new designs.

A light box is an interesting addition to the process of tracing, it does
need batteries, or a USB port. When buying an inexpensive light box ($25),
you might want to consider getting a tiny battery powered [projector][1]
($75) as well.

[Light Boxes Paper on Amazon][2].

[1]: https://www.amazon.com/s?k=Mini+Projector&ref=nb_sb_noss_2
[2]: https://www.amazon.com/s?k=Light+Box+Tracing&ref=nb_sb_noss_2