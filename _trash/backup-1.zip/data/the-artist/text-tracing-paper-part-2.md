On the front you have your trace. On the back you deposit as much graphite
as needed.

Then you place your trace on proper Drawing Paper. Then, go over your trace
one more time, the graphite on the back will now transfer to your drawing
paper.