By blacking out the back of your trace you create Graphite Paper.

You can skip this step by buying pre-made Graphite Paper. (Pre-made
Graphite Paper is a **lot** darker and sharper. If you trace something that
has a lot of small details, you should use Graphite Paper.)

Now you will place Graphite Paper over your Drawing paper, and then put
your trace on top, and then go over it with a pencil.

[Graphite Paper on Amazon][1].

[1]: https://www.amazon.com/graphite-paper/s?k=graphite+paper