Tracing paper does not need batteries, just a pencil.

Anybody can trace a printout of something they like with tracing paper.
What many don't understand is that after tracing, you need to black out the
opposite side of your trace to create a home made, Transfer Paper.