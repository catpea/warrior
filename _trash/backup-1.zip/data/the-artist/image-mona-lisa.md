Using the Mona Lisa to show what you can get by connecting your projector
to your laptop, and using a program like [GIMP][1].

[1]: https://www.gimp.org/