Digital projectors ($100 - $400) are the fastest way to create murals and
paintings.

[Digital Projectors on Amazon][1].

[1]: https://www.amazon.com/Digital-Projectors/s?k=Digital+Projectors