Victorious warriors win first and then go to war, while defeated warriors
go to war first and then seek to win.