Warrior is the oldest name for it. Since our days in Africa we have
progressed forward and the word has evolved many times.

At each stage there are strong lessons to be learned, directly, or
indirectly.

Whatever your calling, wherever you break away to make your stand, even if
you fail to reach the top of your mountain, know that you will surely reach
the rays of the sun, know that you will become part of the Great Family of
Heroes, know that countless many will follow, and that your footsteps will
become a well worn path, in time.

The lessons come from Philosophers, Scientists, Thinkers, Soldiers,
Presidents, Athletes, Mercenaries, Murphy’s Law, Mighty Little Girls &
Young Ladies, Mothers, Sisters, Brothers, and Fathers. From empathy and
compassion, joy and tragedy, triumph and disaster, and great challenges
like learning to live and grieve at the same time, or standing with the
demonized, disposable, or voiceless.

The lessons come from, Choosing Life.

To progress forward, we must be ready to learn to understand by subtle
analogy from all other theories. Theories of survival, of living above the
common levels of life, of choosing heroism, choosing greatness. Striving to
thrive, rising to impossible challenges, learning to overcome pain and
suffering, and standing upon the shoulders of giants to lead the way for
others to follow.