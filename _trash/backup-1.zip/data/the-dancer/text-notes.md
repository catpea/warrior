[Sopot Festival][1] is an annual international song contest held in Sopot, Poland. It was the biggest Polish music festival altogether with the National Festival of Polish Song in Opole, and one of the biggest song contests in Europe.

[Just Dance][2] is a rhythm game series developed and published by Ubisoft. The series was named after the Lady Gaga song of the same title. The original Just Dance game was released on the Wii in 2009.

[1]: https://en.wikipedia.org/wiki/Sopot_International_Song_Festival
[2]: https://en.wikipedia.org/wiki/Just_Dance_(video_game_series)