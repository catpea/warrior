Let us read, and let us dance; these two amusements will never do any harm
to the world.