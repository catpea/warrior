The [Melbourne Shuffle][1] is a rave dance that developed in the 1980s.
Typically performed to electronic music, the dance originated in the
Melbourne rave scene, and was popular in the 1980s and 1990s.

[1]: https://en.wikipedia.org/wiki/Melbourne_shuffle