The one thing that you have that nobody else has is you. Your voice, your
mind, your story, your vision. So write and draw and build and play and
dance and live as only you can.