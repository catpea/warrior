Edward Maya - [Stereo Love][1]

Eiffel 65 - [Blue (Da Ba Dee)][2]

Ryan Enzed - [Stage Rage][3]

Ryan Enzed & Gladius - [Living The Dream][4]

Risk and Enzed - [Repeat After Me][5]

Alan Walker - [Alone][6]

Alan Walker - [Faded][7]

[1]: https://www.youtube.com/watch?v=ixWNDh2XAwE
[2]: https://www.youtube.com/watch?v=zA52uNzx7Y4
[3]: https://www.youtube.com/watch?v=jSiMyTwUfWY
[4]: https://www.youtube.com/watch?v=YVpfEBxTGgA
[5]: https://www.youtube.com/watch?v=HtyAW80KM6U
[6]: https://www.youtube.com/watch?v=1-xGerv5FOk
[7]: https://www.youtube.com/watch?v=1oTUupME0-M