... So I had a manila folder, and I had a Sharpie, and I was like, what am
I going to call this research?

And the first words that came to my mind were "whole-hearted"

These are whole-hearted people, living from this deep sense of worthiness.

So I started looking at the data, and here's what I found:

What they had in common was a sense of courage.

Courage, the original definition of courage, when it first came into the
English language -- it's from the Latin word "cor," meaning "heart" -- and
the original definition was to tell the story of who you are with your
whole heart.