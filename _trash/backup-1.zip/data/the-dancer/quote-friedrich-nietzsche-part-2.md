He who would learn to fly one day must first learn to stand and walk and
run and climb and dance; one cannot fly into flying.