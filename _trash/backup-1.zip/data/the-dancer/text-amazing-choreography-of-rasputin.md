[Rasputin][1] is a 1978 Euro disco hit single by the Germany-based pop and Euro disco group Boney M., the second from their album Nightflight to Venus. It was written by the group's creator Frank Farian, along with George Reyam and Fred Jay.

[1]: https://en.wikipedia.org/wiki/Rasputin_(song)