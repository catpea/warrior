Upload your music to [Soundcloud][1] you get 180 minues of music space for
free (per account).

[1]: https://soundcloud.com