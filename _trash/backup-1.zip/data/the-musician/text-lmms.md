[LMMS][1] is a free, cross-platform tool for music composition.

Take a look at the [showcase][2], albums of songs made with LMMS.

[1]: https://lmms.io/
[2]: https://lmms.io/showcase