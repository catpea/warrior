[Sell][1] your [quality][2] music samples on [Splice][3].

Consider creating less restrictive music/sample sharing platforms (see [The
Founder][4])

[1]: https://support.splice.com/hc/en-us/articles/115006379848-Where-can-I-submit-my-own-samples-or-sample-packs-
[2]: https://splice.com/blog/splice-sounds-quality-principles/
[3]: https://splice.com/
[4]: founder.html