*   [/r/Drumkits][1]
*   [/r/MakingHipHop][2]
*   [/r/EdmProduction][3]
*   [/r/TrapProduction][4]
*   [/r/WeAreTheMusicMakers][5]
*   [/r/IsolatedVocals/][6]

[1]: https://www.reddit.com/r/Drumkits/
[2]: https://www.reddit.com/r/MakingHipHop
[3]: https://www.reddit.com/r/EdmProduction
[4]: https://www.reddit.com/r/TrapProduction
[5]: https://www.reddit.com/r/WeAreTheMusicMakers
[6]: https://www.reddit.com/r/IsolatedVocals/