A **sample** of sound, is the same as a sample of cake, it is just a little
bit of something larger. In the world of music, that little bit, would
often be a defining sound in a song that captured your attention.