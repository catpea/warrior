You don't need a strong beat to make a song work. Izzie Naylor is proof
that minimalist songs are often very beautiful.