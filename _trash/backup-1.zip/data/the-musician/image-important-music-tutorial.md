Please visit [Learning Music][1] at Ableton, and take their music
composition tutorial.

[1]: https://learningmusic.ableton.com/