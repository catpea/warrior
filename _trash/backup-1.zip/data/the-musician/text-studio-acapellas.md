Search YouTube for [Studio Acapellas][1] to discover vocal-only tracks of
popular songs. It is much easier to understand what singing is about when
you can hear the voice without music. You can search the web for "download
youtube audio" and then load them into LMMS and create your own backbeat
and remixes.

[1]: https://www.youtube.com/results?search_query=Studio+Acapella