Please remember what Claudio teaches us. A song is a story, it is not the
back-beat, not the piano, not the twelve inch drum, or the bass head. A
song is a story told with voice and music.

Grab a pencil, draw a line. Mark all the important events along the line.
That's where the lyrics start or end, that's where the back-beat slows or
picks up, that's where your listeners will start to laugh or start to cry.

We compose music, because the greatest of stories cannot be expressed in
words.