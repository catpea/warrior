Sell your music on [Bandcamp][1] (free).

[1]: https://bandcamp.com/artists