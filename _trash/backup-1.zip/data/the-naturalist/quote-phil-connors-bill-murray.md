There is no way that this winter is ever going to end as long as this
groundhog keeps seeing his shadow. I don't see any other way out. He's got
to be stopped. And I have to stop him.