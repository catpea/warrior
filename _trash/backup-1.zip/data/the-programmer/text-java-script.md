The reason I mention JavaScript is because it is the most widely used
programming language on github. [Searching for projects with more than
10,000 stars][1] shows 409 JavaScript based projects, the next one down is
Python with 117.

[1]: https://github.com/search?q=stars%3A%3E%3D10000