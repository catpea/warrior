My definition of a Lady/Gentlelady, or a Gentleman: A person ennobled by
her deeds.

More specifically, the _sum of intent across a person's entire history._

The one lesson that I loved in High School. A Gentleman, an English Teacher
reminding us: "The choices you make today, dictate the life ahead of you.".

And it is those same choices, that will describe who you really are, come a
decade or two from now. Therefore, choose wholeheartedly, beautifully,
heroically, always rising and growing up. Make the choices that the older
you won't regret.