Character of Dr. Sean Maguire as portrayed by Robin Williams is a fine
example of a modern gentleman with class, integrity, and authenticity.