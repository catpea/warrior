Gentlemen emerged from Knights, inheriting the philosophies of Knightly
Virtues. I am sure every fool, wealthy or poor, tried to call him self a
gentleman, but I think back then people paid attention to such claims.

The ease with which we accept lies from people of authority today. Would
not be present had the virtues still mattered to an overwhelming majority.