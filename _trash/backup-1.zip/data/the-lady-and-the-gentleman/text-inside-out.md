There is no force in the universe that can help a person grow up outside
in. In education, the idea of dividing all subjects into tidy categories
that make perfect sense takes away from beauty of Knowledge. Coupled with
the misunderstanding that we can be taught by being talked at, school can
only become an exercise in memorization. A school may make a diploma, but
it cannot make a grown-up.