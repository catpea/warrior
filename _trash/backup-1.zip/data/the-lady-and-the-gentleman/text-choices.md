My friends,

Choose Forbearance, Hardihood, Largesse, Benevolence, and Honour.

Restraint, Dignity, Nobility, Unbreakability, Fortitude, Courage, Love; and
Insight; and Foresight; and Understanding; and Authenticity; and Heroism.