I think, he started learning the most valuable of his lessons, once he
broke out oh the Grade Point Average Prison.

He selected courses that matched the wisdom he already had, he selected
compatible knowledge he was naturally predisposed to integrate.