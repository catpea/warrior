"It is hard to teach kids who stink."

We must face the misjudgment of the role of poverty in education.

We must face the misjudgment of the the gravity of poverty.

We must face policy that does not make sense, that will never make sense,
due to persistent malformed-understanding of education.

Education begins in kindergarten, it is easy to forget this.

It begins with mentors, inspiration, friendship.

There is no education without human connection, but there is merit in apps,
computer programs, videos, audio books, and overhead internet satellites.

We need a clear aim, for both, educators, and the kids. There is no clearer
aim than becoming a Business Creator, and escaping poverty.

Rising to no end in sight. Eventually leaving a worthy legacy. Unbreakable
shoulders for other giants to stand on.

The cure for poverty bears the same pattern as the cure for broken
education. The individual must become a businessperson, just as the student
must become her own teacher.