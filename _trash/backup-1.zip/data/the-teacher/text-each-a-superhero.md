Grades must end, because too many children confuse their grade point
average with their value to the world.

The only reason why someone would ever fail a test, is because the wisdom
they already had, was incompatible with what was being taught.

To force incompatible knowledge on someone, and blame them for not
integrating it, is evil.

If you are young and still in school. Begin making unbreakable promises
that you will fix what is broken. Help your friends to Audio Books that set
them free to understand Science, or travel the Appalachian Trail when
waiting for the bus. Help them understand YCombinator and Techstars,
Startup Accelerators, Angel Funds.

And if you have already left it all behind, now it is time to remember your
hopes and dreams. Go back with your wisdom of today, and fix what was
broken when you were little. Stand up in the classroom and rage against
mediocrity or lies. Take a lesson from Erica Goldson.