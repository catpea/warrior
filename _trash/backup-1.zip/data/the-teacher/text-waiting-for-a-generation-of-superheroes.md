Waiting For You.

And everybody else, to grow up, all the way up, until we become a
generation after a generation of great beings.

Growing up is not optional. Growing all the way up, is not optional.

It is our Health, it is our Right.

It is the only way to break out, and bring about our hopes and dreams of
the future.