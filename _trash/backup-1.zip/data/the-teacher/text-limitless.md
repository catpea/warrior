It is easy to forget that we have no limits.

It is easy to believe the lie, that we can stop because we are not learning
fast enough, or we know enough, or got enough; or had enough.

It is easy to misunderstand the purpose of Education.

We don't need a generation of Brilliant and Unstoppable Teachers, or Policy
Makers. Oh, there will never be enough of those; and there is already far
too many.

Pretending to be wise and authentic is far too easy, to put the future of
humanity in someone else's hands.

Even if it wasn't a fantasy aimed to place responsibility for education
elsewhere, there is no good reason to wait for Policy Makers to update
policy.

We must teach children that they are responsible for their own education,
and their own exit from poverty, by means of becoming a business creator.

Children need an aim, before they open the textbook.

They need persistent enlightenment. Not moronic excuses that they won't
always have a calculator at hand, or sick fantasies of a happy job they
will always love performing.

We don't need better teachers, we need and endless supply of Brilliant and
Unstoppable Students who accept the responsibility for their own education,
at their own pace, and a sequence that matches who they are.

Unbreakable, Unstoppable, Uncontainable, Unpredictable, Uncontrollable
torrent of Superheros under the banner of Unrelenting Pursuit of Excellence
and Love of Wisdom.