Jaime Escalante is the man portrayed by Edward James Olmos in [Stand and
Deliver (1988)][1]

[1]: https://www.youtube.com/watch?v=qtQQC23eseU