"Education is not the filling of a vessel, but the kindling of a flame."

The cradle of education is within. The flame of curiosity, lives within.
Students reach out and put things into their soul, all the time.

Sometimes all it takes is a poem.

Sometimes the explanation, that all education is really for, is beating
back Poverty of Mind-and-Wallet.

Poverty that they were unfortunately and unfairly dropped into, and now
they must learn wisdom and fight their way out of, and if they so choose,
bring back the light so that others may follow.

And later, finally, enjoy their existence and high achievement, leave a
legacy worthy of following.

Never tell a child that life is not fair. That will only force them into
accepting their poverty as a given, and your mediocrity as a fact.

Education is never! for good grades, or a good resume, or a good job that
pays well.

Education is for the opposite of Memorization and Servitude.

Education is for Creativity, and Freedom.

Education is for Originality, and Independence.

Education is for Unbrekability, and Leadership.

The children you taught to wait for Superman, are, that promise, and the
future, and more.

And the opposite of high achievement is not failing while daring greatly.
Failure is nonsense, just another excuse not to try. There is no such thing
as failure. Every step forward adds to success.