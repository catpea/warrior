You may need to consider standardized learning an experiment in helping the
world grow, an experiment so large and complex that it slowly moves at the
pace of decades, if not centuries.

Today, the help is effectively stuck, they are not coming to help you.

Education has reached a point where it can help you memorize, but the
actual learning probably has to be done prior to taking a class.

The teachers can't yet help you, they can't help you meaningfully learn and
fully integrate at a fast enough pace.

Do not relinquish control over your education, knowledge, wisdom,
individuality, and decision making. Your own future, is in your own hands.

Grow up, grow all the way up. Become a Great Being.

Rise, accept the responsibility for your own education, your own
exploration.

Accept the responsibility for your own triumph over poverty.

Accept the responsibility for your own existence.

Decades from now, with your wisdom, with your help, we may be able to do
more for students.

But the challenges you will face are far more complex than broken education.

Quietly helping yourself is just the first step.

Much more complex, and much greater, and far nobler challenges lie ahead.