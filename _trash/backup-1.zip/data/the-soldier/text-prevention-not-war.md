To help a family, you build a library, a school, a free university, you
open borders, and give them aid.

You don't wait until it is too late, and call in the soldiers. War is Evil,
War is Hell.

I think we can learn a great deal from Bryan Stevenson's words _Our
humanity depends on everyone's humanity._

We are one family, one people, there is no "them". It is just you, and me.

All cultures must leave bad ideas behind, and converge on wisdom.

Prevention.