Poverty, Never Changes.

Police in Chicago are calling for tougher sentencing, the gangs are saying
"I have kids, I need to put food on the table".

And one of the lessons we learn from this text is that "A human being is
more than the worst thing they have ever done."

There is a class of soldier that is a product of their environment. Some
are an emergent property of poverty. Maximization of survival, leads to the
emergence of a self taught soldier.