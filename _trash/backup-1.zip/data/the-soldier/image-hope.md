I think there was a hope that hard earned ideas won in hell of war would
spread to no end in time. That, Knightly Virtues, Chivalry, Bushido,
Stoicism, would grab a hold of Humanity and never let go, would never stop
making us better and wiser. But even a [meme][1] has limitations, the gaps
in schooling will end propagation of the most viral lessons, and poverty
will return.

[1]: https://en.wikipedia.org/wiki/Meme