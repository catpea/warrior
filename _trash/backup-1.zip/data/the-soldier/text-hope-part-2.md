My friends, my heroes. The situation is only hopeless when we stand on the
very bottom. When we rise, when we rise onto the shoulders of giants,
things change.

The Hopelessness of Poverty becomes transformed into a Hope. It becomes yet
another mission, a new challenge. It becomes a source of wisdom, a source
of Great Power.