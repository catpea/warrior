Emperor Marcus Aurelius (161-180 AD) shows his clemency towards the
vanquished after his success against Germanic tribes. Marcus Aurelius wrote
a book titled [Meditations][1] and today it is available as an
[Audiobook][2].

[1]: https://en.wikipedia.org/wiki/Meditations
[2]: https://www.audible.com/pd/Meditations-Audiobook/B004IBRMZS