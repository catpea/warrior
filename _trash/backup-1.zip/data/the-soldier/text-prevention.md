I understand restoring law and peace requires armed conflict when there is
nothing else that can be done to help families feel safe.

I don't understand why bloody battles are necessary, why they cannot be
prevented years before it is too late.

The greater battle is in crafting the strategy of deescalation, years,
decades ahead.

The Greatest of Heroes, conspire to prevent conflict, and foster growth; by
means of the Great Art of Fine Disregard for Rule.