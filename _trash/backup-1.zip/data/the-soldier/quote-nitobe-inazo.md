A truly brave man is ever serene; he is never taken by surprise; nothing
ruffles the equanimity of his spirit. In the heat of battle he remains
cool; in the midst of catastrophes he keeps level his mind. Earthquakes do
not shake him, he laughs at storms. We admire him as truly great, who, in
the menacing presence of danger or death, retains his self-possession; who,
for instance, can compose a poem under impending peril or hum a strain in
the face of death. Such indulgence betraying no tremor in the writing or in
the voice, is taken as an infallible index of a large nature - of what we
call a capacious mind, which, far from being pressed or crowded, has always
room for something more.