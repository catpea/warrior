Where a Hunter had to be a hunter or perish, becoming a soldier was almost
optional. A soldier needed training, skill and wisdom to survive into
retirement. A soldier, also needed a tribe as not to live in isolation.

It is in the wisdom of warriors returning from hell of war, that we find
hard earned inspiration and strength; because there isn't a soldier that
does not ask "Why am I in hell?".

One of the most important lessons to take away from this, is that a soldier
is saved inside out, not outside in.