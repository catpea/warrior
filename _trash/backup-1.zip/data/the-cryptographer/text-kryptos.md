[Kryptos On Wikipedia][1]

[Kryptos Transcription by Elonka Dunin][2]

[Elonka's List of Famous Unsolved Codes and Ciphers][3]

[The Cyrillic Projector Code - Cracked!][4]

[1]: https://en.wikipedia.org/wiki/Kryptos
[2]: https://www.elonka.com/
[3]: https://www.elonka.com/UnsolvedCodes.html
[4]: https://www.elonka.com/kryptos/CyrillicProjectorAnnouncement.html