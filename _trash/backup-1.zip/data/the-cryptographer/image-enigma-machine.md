Invented by [Arthur Scherbius][1] attacked by [Polish Cipher Bureau][2]

[1]: https://en.wikipedia.org/wiki/Arthur_Scherbius
[2]: https://en.wikipedia.org/wiki/Biuro_Szyfr%C3%B3w