[Zygalski Sheets][1]

[Bomba (Polish Machine)][2]

[Bombe (British Machine)][3]

[Typex][4]

[1]: https://en.wikipedia.org/wiki/Zygalski_sheets
[2]: https://en.wikipedia.org/wiki/Bomba_(cryptography)
[3]: https://en.wikipedia.org/wiki/Bombe
[4]: https://en.wikipedia.org/wiki/Typex