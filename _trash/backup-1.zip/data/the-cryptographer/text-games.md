[Google Capture The Flag (CTF)][1]

[NSA CRYPTOCHALLENGE - Puzzle of the week][2]

[1]: https://capturetheflag.withgoogle.com/#beginners/
[2]: https://cryptochallenge.io/