lights --highbeams on

lights --highbeams off

dashboard --engine-light off

glovebox --lock passw0rd1

glovebox --unlock passw0rd1