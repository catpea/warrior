A group of commands for compressing files to save space [gzip][1],
[tar][2], and [bzip2][3] to name a few.

[1]: https://linux.die.net/man/1/gzip
[2]: http://man7.org/linux/man-pages/man1/tar.1.html
[3]: https://linux.die.net/man/1/bzip2