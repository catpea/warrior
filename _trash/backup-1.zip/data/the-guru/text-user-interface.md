While Pipes and Redirects of the Command Line are often enough. A number of
Graphical Pipe Editors exists as well, Node-RED is a nice example.