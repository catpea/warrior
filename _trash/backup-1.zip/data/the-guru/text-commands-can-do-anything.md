Commands usually come in groups, for example there is a group of commands
that manage files and directories, a group of commands that compress files,
or download files across the internet.