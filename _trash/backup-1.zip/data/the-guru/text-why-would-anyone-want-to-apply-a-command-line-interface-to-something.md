Because of the uniformity of command syntax. Once you know how to run one
command, you know how to run them all. You just need to pull up the
documentation to see what all the commands are and what arguments they
accept.