Once you learn the shape that a command can take, you will be able to use
any command on any system.

Let us proceed with an imaginary command "print" that has some extra
features.