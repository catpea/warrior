Manage files and directories with [touch][1], [ls][2], [cp][3], [mkdir][4],
[rmdir][5], [mv][6], and [rm][7] to name a few. If you use a file manager
with a graphic user interface (GUI), then you don't need to worry about
these.

[1]: http://man7.org/linux/man-pages/man1/touch.1.html
[2]: http://man7.org/linux/man-pages/man1/ls.1.html
[3]: http://man7.org/linux/man-pages/man1/cp.1.html
[4]: http://man7.org/linux/man-pages/man1/mkdir.1.html
[5]: http://man7.org/linux/man-pages/man1/rmdir.1.html
[6]: http://man7.org/linux/man-pages/man1/mv.1.html
[7]: http://man7.org/linux/man-pages/man1/rm.1.html