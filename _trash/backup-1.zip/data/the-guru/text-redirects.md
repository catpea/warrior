There is also a feature of pipes that creates files and that is the greater
than symbol ">".

print "hello world" | uppercase > greetings.txt

This would result in changing all text to uppercase too, but instead of
seeing "HELLO WORLD" on the screen we’d see it in the file named
greetings.txt