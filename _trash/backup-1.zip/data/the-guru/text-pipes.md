There is a feature in the command world, that can deal with high
complexity, and that is the pipe. Meaning two commands can be connected by
a pipe in the following manner

print "hello world" | uppercase

This would result in changing all text to uppercase, and printing it on the
screen.

HELLO WORLD