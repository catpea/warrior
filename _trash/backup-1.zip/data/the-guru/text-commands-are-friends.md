It is so awesome to just open a terminal, type in gmail alice@aol.com -s
"About Cybertruck" -m "So did you get the $69K build?" and go have your
Irish Breakfast Tea (or an Earl Gray with an extra lump of sugar and an
extended pinkie) a whole 35 seconds earlier, because you didn't have to
wait for the mail window to open and start sucking memory whilst inspecting
its innards.