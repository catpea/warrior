In The Wizard chapter we learned not to confuse the operating system, with
the user interface; as those are two separate kinds of computer programs.

Now we learn that UNIX is an operating system with a user interface
classified as the [Command-line interface][1], let us take a closer look at
the command-line interface.

[1]: https://en.wikipedia.org/wiki/Command-line_interface