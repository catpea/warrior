In the following example there is one argument "hello world". Without
quotes the command would see two arguments "hello" and "world". Quotes are
used to join two or more things together.

print "hello world"