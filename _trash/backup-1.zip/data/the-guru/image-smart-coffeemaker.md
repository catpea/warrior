[Mr. Coffee Smart Coffeemaker enabled with WeMo][1] can be controlled with the bootleg [node.js client for WeMo][2] found on github. As a bonus, you can control burn down you entire house, plus the Coffeemaker.

[1]: https://www.mrcoffee.com/wemo-landing-page.html
[2]: https://github.com/timonreinhard/wemo-client