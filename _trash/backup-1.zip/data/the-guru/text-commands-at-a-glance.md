Here is what a command really looks like:

command-name --some-argument value-of-the-argument

gmail --recipient alice@aol.com --subject "I can't even!" --message "I
can't freaking believe it, commands are cool, rawr!"