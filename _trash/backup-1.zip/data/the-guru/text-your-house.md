lights --off

stove --off

thermostat --heat 72

coffeemaker --on 6AM