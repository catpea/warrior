Most well behaved commands can be executed with the --help argument, or the
-h flag to print some helpful documentation.

print --help

Popular commands will come with manual pages that can be read with the man
command. In this case we would execute: man print