[Website][1] · [Y Combinator on YouTube][2]

[Startup School Videos][3]

[1]: https://www.ycombinator.com/
[2]: https://www.youtube.com/channel/UCcefcZRL2oaA_uBNeo5UOWg
[3]: https://www.youtube.com/playlist?list=PLQ-uHSnFig5MiLRb-l6yiCBGyqfVyVf17