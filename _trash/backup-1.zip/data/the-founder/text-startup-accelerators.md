There are two leading [Startup Accelerators][1] in US. [Y Combinator][2]
and [Techstars][3].

[1]: https://en.wikipedia.org/wiki/Startup_accelerator
[2]: https://en.wikipedia.org/wiki/Y_Combinator_(company)
[3]: https://en.wikipedia.org/wiki/Techstars