Large Startup Accelerator acceptance rates are between 1% and 3%, but there
are [many more][1] smaller ones.

Remember, you and your investors are connected. They make money, when you
make money. Armed with a winning idea you already covered a great deal of
distance towards success.

[1]: https://duckduckgo.com/?q=List+of+Startup+Accelerators&t=ffab&ia=web