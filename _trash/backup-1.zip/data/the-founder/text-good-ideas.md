A good idea, already has desperate customers searching for a way in.

[Google Ads][1] is a Good Idea. Every business person on the internet needs to advertise to get customers to come over. Google has a unique position where many people come to visit its pages, thus they can display ads; they have an advertising network. They have something everybody needs the moment they are ready for their first sale.

[Squarespace][2] or similar, is another great idea. It is a website that can generate a start-up website, based on some screenshots and text. Every start-up has screenshots, and no time to work on the website.

[Wrap Bootstrap][3]: User Interfaces are hard. Having your team create a powerful computer program is one thing, but making it look nice; is another. This is why theme websites make sales. They have all the code, with all the colors and fonts matching, and it saves so much work to focus on the program and have the UI snippets ready.

[Parse][4], because saving data, is huge. When developing applications you need User Accounts, but also some place to store information. Parse has been Open Sourced, and all of the code is available here: [https://parseplatform.org/][5]

[1]: https://www.youtube.com/watch?v=NV4DCdyLNgU
[2]: https://www.squarespace.com/
[3]: https://wrapbootstrap.com/
[4]: https://www.youtube.com/watch?v=89xIe8FbR2g
[5]: https://parseplatform.org/