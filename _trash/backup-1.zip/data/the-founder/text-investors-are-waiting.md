Y Combinator created [Requests for Startups][1], a list of startup ideas
they are waiting for. It includes Enterprise Software, Financial Services,
Programming Tools, and Computer Security to name a few.

[1]: https://www.ycombinator.com/rfs/