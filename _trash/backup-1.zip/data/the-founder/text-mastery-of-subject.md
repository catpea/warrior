What Sun Tzu hoped we understood was this: "Victorious warriors, master the
sword before the battle; while defeated warriors hope to learn how to use
the sword during their first sword-fight."

Creating a tiny company with a winning product, even without filling out
any paperwork. Will give you all the tools you need to sit down with an
Accelerator, or your first investors and show them the relationship between
advertising budget, number of developers, and product sales.

What may feel intimidating when all you have, is an idea; will become
energizing, and empowering when you have some sales to show for it.