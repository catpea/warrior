**Learning Programming** to begin creating such marvels, will also destroy
the pillars behind them; as the languages twist them to meet your own
deadlines.

Sitting down to build your program, and invent it too, is only good for
research, and not for meeting serious implementation goals or deadlines.

You must separate yourself from the implementation (of which, in the end,
there may be many).

You must become the leader, the protector of your vision. And lead - that's
right - [lead your team to victory][1].

[1]: https://www.youtube.com/watch?v=ljqra3BcqWM