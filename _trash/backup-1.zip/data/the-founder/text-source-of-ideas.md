The best source of ideas, is a list of [Winning Companies][1].

Investors [Requesting for Startups][2].

[List of mergers and acquisitions by Alphabet][3].

[Profit Hunt][4] (a play on [Product Hunt][5]) has many smaller ideas along with Monthly Recurring Revenue (MRR).

[1]: https://www.ycombinator.com/topcompanies/
[2]: https://www.ycombinator.com/rfs/
[3]: https://en.wikipedia.org/wiki/List_of_mergers_and_acquisitions_by_Alphabet
[4]: http://profithunt.co/
[5]: https://en.wikipedia.org/wiki/Product_Hunt