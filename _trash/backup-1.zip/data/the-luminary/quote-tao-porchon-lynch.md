There is Nothing You Cannot Do.

Don't say, I'll do it tomorrow, because tomorrow never comes.

One minute after midnight, and it is already today.