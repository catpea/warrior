Who, out of the theory of the earth and of his or her body understands by
subtle analogies all other theories,

The theory of a city, a poem, and of the large politics of these States;