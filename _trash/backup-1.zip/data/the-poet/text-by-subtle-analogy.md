I have once discovered a poem that cradled the very definition of Wisdom.
It simply said: