Do not forget that you are full of poems, that those who are walking near
your footsteps, need.

[Find Rhymes][1], Write Poems.

Become a Great Being.

[1]: https://www.rhymezone.com/