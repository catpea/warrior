"To free the world, to do away with National Barriers. Greed, hate,
intolerance. Let us fight for a world of reason, a world where science and
progress will \[lead us all\] to happiness."

Read You Poems, Record Them, Upload Them. Practice. Share, Teach and
Inspire.