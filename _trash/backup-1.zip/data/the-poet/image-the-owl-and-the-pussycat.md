[The Owl and the Pussycat at Wikipedia][1].

[1]: https://en.wikipedia.org/wiki/The_Owl_and_the_Pussy-Cat