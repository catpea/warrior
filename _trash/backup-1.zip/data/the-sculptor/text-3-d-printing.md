Shapeways offer printing services, but you can also purchase your own [3D
Printer][1] for quicker prototyping

[1]: https://en.wikipedia.org/wiki/3D_printing