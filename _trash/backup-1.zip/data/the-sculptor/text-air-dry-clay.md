Air Dry clay can be purchased for $25 for 25lb at [Amazon][1]

[1]: https://www.amazon.com/AMACO-AMA46317P-Clay-Gray-lbs/dp/B0009RRTA8/ref=sr_1_10?keywords=air+drying+clay&qid=1574898467&sr=8-10