Where did I learn to understand sculpture? In the woods by looking at the
trees, along roads by observing the formation of clouds, in the studio by
studying the model, everywhere except in the schools.