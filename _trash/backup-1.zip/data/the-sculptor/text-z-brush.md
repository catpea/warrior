Zbrush is a commercial product priced at $1,000.

(I recommend learning Blender)