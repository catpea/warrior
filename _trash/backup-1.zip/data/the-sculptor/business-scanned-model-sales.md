You are not limited to digital models, you can experiment with [3d
scanners][1] as well. Take a look at the [Shapeways Marketplace][2] for
more ideas.

[1]: https://en.wikipedia.org/wiki/3D_scanning
[2]: https://www.shapeways.com/marketplace