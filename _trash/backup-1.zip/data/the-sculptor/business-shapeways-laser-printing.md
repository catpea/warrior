[Sell][1] your 3D models through Printing on Demand (POD, printing only when someone pays for your product) at [Shapeways][2] and similar 3d print shops. Shapeways created [shapejs][3] a programmable product creator with many [examples in JavaScript][4], this can be used to generate a large number of unique products (antique coin pendants, tiny statues of art in public domain, odd bobble heads, skeleton wallets, waveform rings, UPC/QR code bracelets or keychain doodads.).

[1]: https://www.shapeways.com/marketplace
[2]: https://www.shapeways.com/
[3]: https://shapejs.shapeways.com/
[4]: https://shapejs.shapeways.com/v2/examples