We can infer some really important facts about who we are based on where we
come from, we can even imagine the diet we evolved alongside with.

It is worth mentioning that before big rocks, and spears, we would chase
animals to death in an act called [Endurance Hunting][1]

[1]: https://en.wikipedia.org/wiki/Persistence_hunting