We belong in communities, not to live in isolation.

We grew up protecting each other, casting out those who stand in the way of
future generations, looking after the little ones so that they may grow to
become great hunters.