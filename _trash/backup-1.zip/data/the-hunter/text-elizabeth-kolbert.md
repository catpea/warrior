Elizabeth Kolbert wrote two life changing books [Field Notes from a
Catastrophe: Man, Nature, and Climate Change][1] and [The Sixth Extinction,
An Unnatural History][2]

[1]: https://www.audible.com/pd/Field-Notes-from-a-Catastrophe-Audiobook/B002V8MJPS
[2]: https://www.audible.com/pd/The-Sixth-Extinction-Audiobook/B00FZ4JEAS