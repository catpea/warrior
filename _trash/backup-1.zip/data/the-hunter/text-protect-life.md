Just from this overview alone, you get the picture of how capable we are,
how noble, how unbreakable, how magnificent.

We have superior cooling, superior intelligence, and we did well hunting
without spears.

We did not store fat, we were lean, and we knew hunger well.

We are hunters, not for sport, but for survival.

We ate fruit, vegetable, meat; that’s out optimal diet, the nutrients that
we evolved to require for our optimal health.