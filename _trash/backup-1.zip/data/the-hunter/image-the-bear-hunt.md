This artwork has been with me for as long as I can remember, I found it in
a book entitled “Wszechświat życie człowiek” (Universe, Life, Human) and
one of my favorite writers Bill Bryson wrote something just as good [A
Short History of Nearly Everything][1] which is available as an
[Audiobook][2] where he gently talks about learning, and what he learned
about our universe.

[1]: https://en.wikipedia.org/wiki/A_Short_History_of_Nearly_Everything
[2]: https://www.audible.com/pd/A-Short-History-of-Nearly-Everything-Audiobook/B002V0KFPW