We are part of Nature, part of Planet Earth, we depend on it for our health
and [Survival][1]

[1]: https://youtu.be/TMrtLsQbaok