My Grandma taught me to ask "Quo Vadis?" it is from Latin, it means
"Whither goest thou?" or "Where are you going?".

At 3:41 the brave mercenary describes himself as someone who was
"Programmed to Destroy". While he was growing in his wisdom, he perceived
the lack of it, as "being programmed". There is an old saying "A learned
servant is not a useful servant", wisdom set Mr. Mander free.

Quo Vadis? is a repeating decision making pattern among the great beings.
Mr. Mander in what he calls his "True Act of Bravery" (3:49). Uses it to
"ensure \[that\] there'll never be separation between who I am, and what I
do", to ensure his Authenticity, Harmony, Dignity, Integrity, Sanity. He
also asks "Quo Vadis?" in the larger question surrounding both "Does that
elephant need its face more than some guy in Asia needs a tusk on his
desk?" and "Would I be brave enough to give up everything in my life to try
and stop the suffering of animals". The result of these Authentic Brave
Queries is the [International Anti-Poaching Foundation][1]. From Mercenary,
to a Warrior, a Legend, a Great Being.

Lucy Hone is yet another Great Being who employs this type of thinking
especially when asking "Is what I'm doing helping or harming me?" see
[Superhero Chapter][2] for her advice on the subject of Unbrekability and
Resilience.

[1]: https://www.iapf.org/
[2]: superhero.html