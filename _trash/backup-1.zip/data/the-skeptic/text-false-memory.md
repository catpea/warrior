Article adjustment on eyewitness report. Loftus' meta-analysis on language
manipulation studies suggested the phenomenon effects taking hold on the
recall process and products of the human memory. Even the smallest
adjustment in a question, such as the article preceding the supposed
memory, could alter the responses. For example, having asked someone if
they'd seen "the" stop sign, rather than "a" stop sign, provided the
respondent with a presupposition that there was a stop sign in the scene.
This presupposition increased the number of people responding that they had
indeed seen the stop sign.

Visit [False Memory][1] for more.

[1]: https://en.wikipedia.org/wiki/False_memory