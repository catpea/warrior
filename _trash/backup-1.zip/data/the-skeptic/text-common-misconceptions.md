The widespread urban legend that one swallows a high number of spiders
during sleep in one's life has no basis in reality. A sleeping person
causes all kinds of noise and vibrations by breathing, the beating heart,
snoring etc. all of which warn spiders of danger.

Visit [List of common misconceptions][1] for more.

[1]: https://en.wikipedia.org/wiki/List_of_common_misconceptions