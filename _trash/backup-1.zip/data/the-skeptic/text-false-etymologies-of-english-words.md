The actual origin of the phrase "the whole nine yards" is a mystery, and
nearly all claimed explanations are easily proven false. Incorrect
explanations include the length of machine gun belts, the capacity of
concrete mixers (in cubic yards), various types of fabric, and many other
explanations. All are probably false, since most rely on nine yards when
evidence suggests that the phrase began as "the whole six yards". In
addition, the phrase has appeared in print as early as 1907, while many
explanations require a much later origin date.

Visit [List of false etymologies of English words][1] for more.

[1]: https://en.wikipedia.org/wiki/List_of_common_false_etymologies_of_English_words