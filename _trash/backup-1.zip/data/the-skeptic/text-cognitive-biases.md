Cognitive biases are systematic patterns of deviation from norm or
rationality in judgment, and are often studied in psychology and behavioral
economics.

Visit [List of cognitive biases][1] for more.

[1]: https://en.wikipedia.org/wiki/List_of_cognitive_biases