When Ken Thompson and Dennis Ritchie began creating the Unix operating
system in 1969, they did not envision that their work would become a
backbone of the computer revolution that has transformed the world [»][1]

Some commands will be hard to remember, or just look too confusing. That's
because something went wrong in their creation, maybe there wasn't enough
funds, or the programmer was still learning UNIX.

Forgive the ugly, and remember the promise of UNIX, and UNIX-like operating
systems. The command line is here to make your life simpler.

Dear Reader, UNIX is here to convince you that you are a wizard, hairy; and
armed with many a fancy spell to hoot.

[1]: https://www.sfgate.com/business/article/Ken-Thompson-Dennis-Ritchie-win-Japan-Prize-2478569.php