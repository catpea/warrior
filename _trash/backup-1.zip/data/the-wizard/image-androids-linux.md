The Android based Phone, is actually a Graphical User Interface to an
underlying Linux Operating System. It is possible to prevent the loading of
the Android Graphic User Interface, and end up in the underlying Linux
Command Line Interface (CLI). You can then connect a USB keyboard to your
phone, and type commands at it using the CLI.