In the fantastic video below you will learn about the old User Interface to
the UNIX Operating System: The Command Line Interface.

UNIX, Linux, Windows, Commodore. Can each be divided in two simple layers,
the underlying Operating System (OS), and the front-facing User Interface
(UI).