Google has locked down their own OS, they don't want to let developers in.
So, there is a new phone on the market, that all the nerds are hoping will
be a dream. They may actually ship with a proper Terminal, where you have a
proper Linux (Clone of UNIX) home directory, and can install generic
software. Visit [https://puri.sm][1] for "Laptops & phones that protect the
privacy of your family and the security of your business."

[1]: https://puri.sm/