Microsoft went through a similar upgrade. Microsoft DOS, a Command Line
product was released in 1981.