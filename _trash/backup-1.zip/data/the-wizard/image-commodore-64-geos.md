In 1986 Berkeley Softworks came about and made the [GEOS][1] (Graphic
Environment Operating System) for use with the [Commodore 1351 Mouse][2]

[1]: https://en.wikipedia.org/wiki/GEOS_(8-bit_operating_system)
[2]: https://en.wikipedia.org/wiki/Commodore_1351