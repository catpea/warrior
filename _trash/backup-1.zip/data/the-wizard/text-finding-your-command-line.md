Your own operating system has a command prompt as well. If you use Windows
it will not be as flexible as Mac, but it is still a good example of a
Command Line Interface.