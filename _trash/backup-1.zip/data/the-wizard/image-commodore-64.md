For Example, the designers of my first computer, the Commodore 64; decided
that the best interface for a little computer is a Language Shell. Not a
Command Line, not a Graphic User Interface, but what we would call today a
[REPL Shell][1], I would describe the Commodore UI as an efficient early
Code Editor.

[1]: https://en.wikipedia.org/wiki/Read%E2%80%93eval%E2%80%93print_loop