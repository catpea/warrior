Windows is not the best for Command Line Interface magic, but don't worry
you can just buy the reasonably priced [Raspberry PI][1] (the green PCB
board thing between monitors and keyboard in the picture above), make sure
you get the latest version (It was [Raspberry PI 4][2] in December of
2019). I recommend you go all out and get the maximum memory 4GB (at the
time of writing), along with Raspberry PI branded Keyboard and Mouse, to
show everyone that you mean business. Get two nice monitors as well (you
don't have to get the 4K)

[1]: https://www.raspberrypi.org/
[2]: https://www.raspberrypi.org/products/raspberry-pi-4-model-b/?variant=raspberry-pi-4-model-b-4gb