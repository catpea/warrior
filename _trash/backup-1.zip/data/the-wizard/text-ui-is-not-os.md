You should not confuse the Operating System, with the User Interface; as
those are two separate kinds of computer programs. An Operating System, can
have many types of User Interfaces.