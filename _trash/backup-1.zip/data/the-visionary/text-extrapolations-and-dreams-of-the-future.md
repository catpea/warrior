[Sam Harris][1]

[Craig Venter][2]

[Ray Kurzweil][3]

[Aubrey de Grey][4]

[1]: https://en.wikipedia.org/wiki/Sam_Harris
[2]: https://en.wikipedia.org/wiki/Craig_Venter
[3]: https://en.wikipedia.org/wiki/Ray_Kurzweil
[4]: https://en.wikipedia.org/wiki/Aubrey_de_Grey