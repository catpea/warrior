[Skeuomorphism][1] brings things that almost feel touchable, to the flat touchscreens of today. Visit [A Showcase of 50 Skeuomorphic Designs][2] for more.

[1]: https://en.wikipedia.org/wiki/Skeuomorph
[2]: https://www.dtelepathy.com/blog/inspiration/50-skeuomorphic-designs