Visit [Fantasy UI at Pushing Pixels][1] for more.

[1]: https://www.pushing-pixels.org/fui/