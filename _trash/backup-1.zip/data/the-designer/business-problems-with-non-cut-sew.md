Below is a picture of why you must choose the Cut & Sew method. The
printing process on pre-made garments is flawed, the gas will not permeate
wrinkles that are sure to occur on pre-made garments. You must first create
the fabric, and then Cut & Sew the garment. Take a look at the [source
video][1] that demonstrates the problem with sublimating pre-made garments
in a bit more detail.

[1]: https://www.youtube.com/watch?v=IQdPP04qEwU