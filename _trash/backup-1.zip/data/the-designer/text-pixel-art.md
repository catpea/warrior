[Pixel Art][1] is a form of digital art, created through the use of software, where images are edited on the pixel level. Visit [22 Pixel Artists Creating Beautiful Retro Masterpieces][2] for more.

[1]: https://en.wikipedia.org/wiki/Pixel_art
[2]: https://weloveitbut.com/best-pixel-artists/