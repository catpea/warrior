[eBoy][1] are an inspiration for business ideas.

[1]: http://hello.eboy.com/eboy/