Inspired by the breathtaking [Ashes Scene in The Big Lebowski][1]

[Website][2]

[1]: https://www.youtube.com/watch?v=u44D3qKKGPU
[2]: https://www.behance.net/gallery/12753749/Pixelwood