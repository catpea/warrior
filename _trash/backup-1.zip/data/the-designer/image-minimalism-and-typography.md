[Typography][1] is an example of minimalism. When things get too complicated, and there are too many colors, just delete everything and remember Minimalism. Visit [Beautiful Web Type][2].

[1]: https://en.wikipedia.org/wiki/Typography
[2]: http://hellohappy.org/beautiful-web-type/