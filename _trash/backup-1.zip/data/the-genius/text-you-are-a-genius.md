Genius, is a collector, and a master of frameworks.

One of the most pop frameworks, is English. Or as we will call it here: The
English Framework for Advanced Human to Human Communication.

The "Double U", the 26 unsqiglies (as I call them - my original alphabet
has extra squiggly letters I never knew what to do with). And then the
comma and, Oxford Comma, the mysterious semicolon, the haunting tilde?

Rhymes.

Poems.

Songs.

Letters.

Essays.

Transcribing Lyrics, of a song that paused your time, classes, grades,
parents?

Memorizing Poems?

Quotes? To thine own... yeah you did.

Speaking. Reading. Writing.