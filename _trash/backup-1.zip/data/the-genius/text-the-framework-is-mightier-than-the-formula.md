Armed with this knowledge, our young lady, can arrive at her own πr², when
needed.

But also at E=mc², and all the wonderful rest.

And so can you. My Genius Reader.