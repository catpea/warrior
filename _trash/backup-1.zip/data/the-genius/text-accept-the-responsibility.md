People laugh off running out of water, but that's actually terribly simple.

It will happen like this: [U.S. drinking water widely contaminated with
'forever chemicals'][1]

But remember, all problems created by Humans, can be solved by Humans too.

[1]: https://news.ycombinator.com/item?id=22116696