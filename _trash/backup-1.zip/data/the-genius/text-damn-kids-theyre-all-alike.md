When I was learning English, my most powerful piece of literature was The
Conscience of a Hacker, or [The Hacker Manifesto.][1] (See External Links
section for Hacker's Manifesto at Phrack Magazine)

I am wiser now, the text is for a teenager. But I feel no shame for still
holding it dear to my heart. I am glad to share with you.

[1]: https://en.wikipedia.org/wiki/Hacker_Manifesto