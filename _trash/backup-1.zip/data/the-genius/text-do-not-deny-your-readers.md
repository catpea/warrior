Do not deny your stories to those who are still learning the lessons you
have already mastered.

What if your "Not good enough", will become the best they ever had?

Mightier than The Sword.