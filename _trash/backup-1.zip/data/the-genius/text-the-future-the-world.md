You were born a Genius. You are a Genius. It is not even that big of a
deal, you are a human with a brain, Genius is what we do. On the other end,
people saying they are better than you because they are a Genius, are sick
from poverty of mind, they got fractured, stuck. It is sad, let us hope
they feel better and catch up, but pass them on as they heal.

Keep moving forward, keep learning, the World needs you to grow, to grow
all the way up, you, and all your peers, and all generations to come.

It is the journey of self education that makes the real difference.

Begin your journey under the banner of Unrelenting Pursuit of Excellence
and Love of Wisdom.

The Future, and The World, it will all be Yours.

You are far more than Genius.

Unbreakable.

Unstoppable.

Uncontainable.

Unpredictable.

Uncontrollable.

You Are The Future.