Study your Frameworks.

Generations have tried to avoid Genius, and the World is hurting for it.

We are bound to this planet, chemically, biologically, even intellectually.

We are all connected.

There is no moving to Mars.

And we were never allowed to let the TV, or the talking-heads, or lairs, do
the talking - with each new generation, doubly so.