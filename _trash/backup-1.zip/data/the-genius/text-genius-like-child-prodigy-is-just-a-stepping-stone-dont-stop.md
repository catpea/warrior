You are to surpass what you think Genius is, on your way up, to growing all
the way up.

This act of transcendence will recur several times, depending how busy you
get in life.

Some things you think are one-way today; High School, Roswell,
Globalization, Content of Character, Memorable Words, Superstars,
Mokele-Mbembe, Spelling and Grammar (To use my teenage mind as example)
will change meaning, as you grow; possibly/hopefully even reverse.

Similar to how "We make use of a service already existing without paying
for what could be dirt-cheap if it wasn't run by profiteering gluttons, and
you call us criminals." turns around, as we learn that Criminal
[Phreaking][1] is just not worth the damn prison time.

My Dear, Friends, Readers. You have mastered English.

You have easily mastered something only a genius child prodigy could.

Didn't even notice it, English came so naturally, so simply - didn't it?

... and you say you are not a Genius?

Wow, just wow.

[1]: https://en.wikipedia.org/wiki/Phreaking