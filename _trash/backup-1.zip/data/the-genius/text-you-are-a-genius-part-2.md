Because storytelling, inspiration, sharing of wisdom, is just a part of The
English Framework for Human Communication - that you mastered without
noticing... as a child.

At the age of 15 or earlier, you master a framework almost as complex as
any of the more interesting Daughters of Philosophy (The Sciences).

It comes to you so naturally, that you don't notice it.

You think we are born with the ability for language.

But, no.

And not only do you learn it, your brain grows to match the complexity of
information and tools needed to manipulate it.