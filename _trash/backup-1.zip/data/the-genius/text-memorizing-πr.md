Do you remember memorizing πr²?

Forcing memorization of πr² or any formula, should be seen as psychological
torture, means of intimidation. It should be seen as cause for suspension
of the teacher, and review and repair of the damage they made.

Formula memorization is the same as being forced to learn English without
the use of alphabet. It is incredibly cruel.

Some young lady out there, tears in eyes can't comprehend πr², and her mind
rejects memorization, she NEEDS to know - tears in eyes - why is the r is
squared? Her mind reaching for why is the r multiplied by it self. Is there
a geometric square somehow?

Warm, but not warm enough.

A brilliant mind yearning for arriving at the formula herself, yet forced
to merely blindly accepting it, or repeating the whole year.

People who need to invent the formulas, people who have the natural
predisposition for abstract theoretical mathematics... The naturally
predisposed for abstract mechanics or Mathematics, are being forced, not
to, learn Mathematics, or be punished.