My friends, the story of [Grendles Mōdor][1] remains unfinished, [Ides][2]
Aglæcwif of Ælwihta Eard; beacons her side to be writ. Was Grendles Modor a
monster, would she be an Ide then?

Was the Dragon a mere reminder, a clumsy blurb for [Memento Mori][3] or is
that just the introduction to the real story, the story that has little to
do with men like Beowulf who can't even take down a fat flying lizard
right. A story burned to the ground by the spirit of the age, the Greatest
Story Never Told, The Story of The Ides of the Old World.

Pick up the pen. Rebuild the story a thousand times, and let the version
1001 earn you a place in history.

[1]: https://en.wikipedia.org/wiki/Grendel%27s_mother "Grendel's Mother"
[2]: https://en.wikipedia.org/wiki/Idis_(Germanic)
[3]: https://en.wikipedia.org/wiki/Memento_mori