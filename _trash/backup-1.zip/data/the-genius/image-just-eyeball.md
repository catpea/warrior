Just witness that half the circumference of the circle (4 slices) are used
at the the base of the rectangle, because the other four are used up top.
It really does not matter how many divisions of the circle so as long as
reaching infinity makes for an infinitely perfect rectangle ❤