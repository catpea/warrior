Once you have the framework down, you gain special abilities, like
Storytelling, for example.

You can warp facts to construct fantasies based on real events and beings,
now transformed into Mighty Ice Giants, maybe Dragons, Lost Worlds, and
Faster Than Light Travel.

You can encode a lifetime of experience in an exciting story with enchanted
objects, and transcendental superhero journeys, here you can easily pass on
a message across centuries. You can leave stones unturned that will mark
forks and joins that will call to others to add to your story, to keep it
alive across centuries even as English evolves.