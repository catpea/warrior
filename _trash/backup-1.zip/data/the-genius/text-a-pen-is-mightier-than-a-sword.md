Genius, is to answer the challenge. Ælwihta Eard, is the world of our
childhood stories, from Baba Jaga, to The One Ring, to Harry Potter, and
beyond.

Genius is to pick up the pen, and not fear sounding foolish.