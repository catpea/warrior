...

We explore... and you call us criminals.

We seek after knowledge... and you call us criminals.

We exist without skin color, without nationality, without religious bias...
and you call us criminals.

You build atomic bombs, you wage wars, you murder, cheat, and lie to us and
try to make us believe it's for our own good, yet we're the criminals.