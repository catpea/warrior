Genius is knowing the framework mechanics, and reinventing the formulas as
needed.

Sometimes, applying mechanics from one place by subtle analogy to another.

For example apply lessons from trains and their relativity of motion and
distortion of sound waves, to other things...