Drums do beat.

Beat is what your foot does when you like a song. There will be a rhythm
within a song almost always represented by a drum kit. A low deep sound
with some stuff happening behind it. That stuff behind it is the drum kit.

Listen, The Drum Kit, is just an instrument. If it was just the drums, it
would be like a piano with one key. There is more to drums, there are some
quick sharp sounding things that go along with it.