Look how keys go together, only when melody gets too boring, is there a
huge shift, a kind of a bridge, to get you to the next melody.

Notice the Intro, the song does not really start until Ralph Wiggum ends up
wearing Jebediah Springfield's Head as a hat.

Look how the song has quick melodies, followed by longer key presses, and
quick little melodies again. This way none of the parts get boring, and the
song keeps going.

Notice the Outro. The moment Matt Groening name is displayed, a new
variation pops up, and it is a melody that has a very nice closure at the
end. It does not seem to leave off unfinished, it hits those four final
notes in a sequence, and you know it is done, and done.