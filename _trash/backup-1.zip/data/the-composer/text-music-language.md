You don't need to know musical notation.

Musical notation has been replaced by a SAVE BUTTON.

No, you do not need to know Musical Notation to read Chopin's Nocturnes,
either.

You just import the midi file into lmms, and gaze. He is not smarter than
you, he just sat at a piano making melodies, wrote them down arranged them
in a song, and became famous for having picked nice ones.

(Don't listen to people telling you that you can't become a World Famous
Maestro, because you don't know notes. They are just salty because they had
to learn them, and you don't.)

Like languages, music evolved to match our abilities. Everyone is a
composer. The rules are very simple.

Drums must be low and simple one or two keys. When making melodies don't
jump around, transition from one nearby key to another, they are grouped to
sound nice together. Break the rules from time to time.