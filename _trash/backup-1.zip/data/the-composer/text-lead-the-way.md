My Friends, My Readers, play.

Revolutionary Warriors. Lead The Way.

Let no one stand in it, may they face your wrath.

Make your own path.

Let no one play you like a piano key.

Be the change, you hope to see.