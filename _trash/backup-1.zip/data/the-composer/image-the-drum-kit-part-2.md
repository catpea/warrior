In general the instrumental sounds that can be created here fall under four
basic categories.

Kick from [A bass drum, or kick drum][1]

Snare from the [Snare Drum][2]

Closed Hat & Open Hat from the [Hi-hat][3]

Clap, that's the sound that clapping your hands makes.

[1]: https://en.wikipedia.org/wiki/Bass_drum
[2]: https://en.wikipedia.org/wiki/Snare_drum
[3]: https://en.wikipedia.org/wiki/Hi-hat