You can see the same pattern in the video below, it is just rotated 90°
clockwise.