You must never fear.

There are many theories.

Newton, went as far as saying that he made Calculus more complicated than
it should be, on purpose.

Chopin, would never dare to simplify his work.

But that won't stop me.