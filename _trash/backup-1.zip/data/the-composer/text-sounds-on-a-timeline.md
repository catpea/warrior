Visualize notes as bright little objects on a timeline.

Watch the melody.