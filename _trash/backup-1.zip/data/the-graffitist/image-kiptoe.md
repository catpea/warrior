[Kiptoe on YouTube][1]

[1]: https://www.youtube.com/channel/UCwcDy-AjZJ5T7DH9BWaOMZg