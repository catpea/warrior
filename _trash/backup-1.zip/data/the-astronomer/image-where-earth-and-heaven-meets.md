To put it simply, before you can create a warrior, you must first create a
universe.

Yet another image from “Wszechświat życie człowiek” (Universe, Life, Human)
and this one is actually in Bryson's [book][1] (the paper version).

[1]: https://en.wikipedia.org/wiki/A_Short_History_of_Nearly_Everything