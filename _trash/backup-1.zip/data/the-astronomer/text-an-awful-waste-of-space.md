Character of Dr. Ellie Arroway (Jodie Foster) in Carl Sagan’s [Contact][1]
was inspired by Jill Tarter.

[1]: https://en.wikipedia.org/wiki/Contact_(1997_American_film)