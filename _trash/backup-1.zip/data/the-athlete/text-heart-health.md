Recently published article on how [Human Hearts Evolved to Need Regular
Activity][1]

[1]: https://www.insidescience.org/news/human-hearts-evolved-need-regular-activity