Bill Bryson’s book about walking the Appalachian Trail [A Walk in the
Woods][1] was made into a movie (comedy) where Bill Bryson is played by
Robert Redford. Please listen to the [Audiobooks][2] first.

[1]: https://www.audible.com/pd/A-Walk-in-the-Woods-Audiobook/B0091J9AQQ
[2]: https://www.audible.com/pd/A-Walk-in-the-Woods-Audiobook/B0091J9AQQ