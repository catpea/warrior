I saw the best minds of my generation destroyed by madness, starving
hysterical naked, dragging themselves through the negro streets at dawn
looking for an angry fix, angelheaded hipsters burning for the ancient
heavenly connection to the starry dynamo in the machinery of night...