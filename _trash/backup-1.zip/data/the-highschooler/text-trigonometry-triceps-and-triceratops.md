At first we thought we were the losers. We certainly had the grades to
prove it. We formed a club. We sarcastically called it The Breakfast Club
after an old movie. We expected to be held back, and eventually kicked out.

We didn't expect to be seen as the gifted ones.

But we had the gift of courage, the gift of search for a clear road ahead.
And that road turned out to be becoming a Businessperson, a Founder, a CEO.
It was a path that mixed education with rewards, leading onward to
independence and a majestic triumph, albeit through many a failure.

In school, we were being forced to memorize Trigonometry, Triceps and
Triceratops, when what we really needed was help with finding investors to
scale our little Breakfast Club business.