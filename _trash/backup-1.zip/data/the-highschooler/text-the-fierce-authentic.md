Staying in school had a negative impact on our education, on our futures.
College and Premed brought sleep deprivation into the farce, it was a
dangerous joke.

In the end all we had was our friendship. The school was tearing us apart,
the Start-ups kept us together.

Looking back at how young we were, how unbreakable, how fierce.

Though we didn't believe in schools, we doubted ourselves for years. Now,
looking back, we searched for mentors, but none were to be found. But, in
the absence of teachers, we became the teachers.

To quote an old commercial: We were The Crazy Ones, The Misfits, The
Rebels, The Troublemakers, the round pegs in the square holes, the ones who
saw things differently, who were not fond of rules, and had no respect for
the status quo.

We were the ones crazy enough to think we could change the world...

... and we did ...