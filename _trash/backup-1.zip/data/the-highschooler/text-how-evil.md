Alas, teaching whilst failing to educate, is fraud.

Parading the coffee lovers, who want to breeze through with a 4.0 GPA, to
get the hell out, and move past this damn charade. Parading them as
successfully educated students, is fraud.

Making the quiet girl cry because she wanted to comprehend and not merely
memorize, is evil.

Turning face away, when the fat kid is being bullied, beaten, assaulted,
threatened, kicked, held down, spat upon, is evil.

Sending a kid back home, when you just witnessed his father beating him in
the bathroom for the bad grades he ended up with, because he can't memorize
anything when he is under constant threat from everybody, is evil.

Failing to authentically educate, and then grading down those who rejected
the memorization dog and pony show, is evil.

Pretending to teach under the poisonous threat of repeating the grade or
year, semester or class, threatening kids to stop learning, and start
memorizing, is evil.

Sending kids home to angry, often violent parents, because they rejected
fake education, fake tests, fantasy GPA, is evil.