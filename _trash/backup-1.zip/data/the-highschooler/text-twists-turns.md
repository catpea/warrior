To accomplish all this, some changes needed to be made, they first
convinced themselves that they were doing a great job so as long as they
were working hard, and then some things needed to be taken away, and a few
needed to be twisted around.

We were forced to recognize that teachers work really, really hard, that
the administration works very hard, it is all hard work, extremely
stressful. People give up days off, cancel vacations, make sacrifices.

To question administration or teachers while they work that hard, makes for
a heartless, cruel, shameful petty little student.