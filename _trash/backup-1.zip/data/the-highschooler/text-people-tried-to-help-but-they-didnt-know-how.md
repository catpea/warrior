Someone said that the only reason the teachers seemed to know more than we
did, was because they had to regurgitate that same stuff every year to keep
their jobs...

Each time it came up; there was always someone to say that they wanted to
help us, but in the end they seemed to have wanted to assimilate and
destroy, embrace and extinguish. Get the gifted ones out of the system to
make things easier for themselves, to calm the waters - if nothing sticks
out, it must be all good.

Nobody, really, took grades seriously because of how easy it was to cram
before a test, pass it, and forget it. Since tests did not represent
student knowledge, grades did not represent the student. Everyone knew
this, nobody said anything because once the students realized the school
was mostly a charade they just wanted to graduate and move on.

Overwhelming majority of Teachers didn't want to change anything because
they didn't want to make their job any harder, they just want to get paid
and go home. Statistically half of them quit anyway.

Management was focused on grade points and funding.

Everybody else was parading solutions, but there was no time, any extras
were aimed at symptoms, extras just added to the weight of existing
problems.

The root cause was that we were not safe, and we were not learning.