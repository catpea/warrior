"Today, we'll get it all working, and today we'll get paid. Tomorrow,
tomorrow, when everything is worked-out and working, we'll get to the
students - one thing at a time." - They'd say.

But we knew that tomorrow never comes, once the new day starts, it is
already today. The tomorrow they thought of, was more of a garbage can for
nice-to-haves.

They were working very hard, and it was all very hard work. But they didn't
have the strength to do both, their job, and make schools work.

In effect, everyone forgot about us. They forgot we were the point and the
future. Their aim was no longer our education, but merely staying in
business by arranging for what in effect became, an impression of one.