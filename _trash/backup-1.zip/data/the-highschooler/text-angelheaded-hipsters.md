The biggest of the troublemakers had the most brittle souls, they were the
first to shine, the mightiest of the thinkers, the best of the survivors,
but tragically also the first to have their spark dim under threat and
pressure.

Already forged in battle at home, the betrayal of schooling was the tipping
point for many.

They just couldn't resist parents, or pressure, or grades, not for that
long, it was not human to live perpetually frightened in constant fear.

The schools added to the dark forces already crushing them, the teachers
were supposed to kindle their flame, but they filled their vessel and often
extirpated their spark.