At first, nobody wanted to talk to us.

There was a problem with how Investors viewed people who paraded their GPA
or even completed schools.

The Investors didn't want followers, and above all they didn't want
cheaters that tried to pass their GPA as something authentic or even
meaningful.

The Investors sought Natural Born Leaders, they sought Evidence of
Exceptional Ability.

The Investors sought people who rejected the inauthenticity of broken
education and didn't partake in stupid charades.

It was almost like High School became a mechanism to keep the
administration busy, the teachers blind, the students poor, and the parents
dreaming.