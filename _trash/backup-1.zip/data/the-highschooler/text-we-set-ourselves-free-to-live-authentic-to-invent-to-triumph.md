We accepted the responsibility for our own education.

We begun learning on our own, through internet, Audio Books, trial and
error.

We begun building more and more small companies, and the more we failed the
wiser we became.

The moment schools begun interfering with our companies, with making money
that we used to support ourselves, we became dropouts.

But we did look back, we aimed to fix Education. To make all those
countless forgotten aches and pains count.