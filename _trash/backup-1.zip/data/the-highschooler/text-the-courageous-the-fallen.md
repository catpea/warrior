The others secretly saw us as courageous, strong and unbreakable, healthy
and authentic. But they didn't really know how to relate to us. We were the
same but they were too confused by the noise of homework, quizzes, tests,
and grades, chores, parents, circles, and punishment, punishment everywhere.

The threat of repeating classes, reliving the same noise, or being held
back was exactly like prison. Neurologically, Threat and Punishment
interferes with Neurogenesis. For the most Delicate, it wasn't just
difficult to cram and memorize, it might have been neurologically
impossible.