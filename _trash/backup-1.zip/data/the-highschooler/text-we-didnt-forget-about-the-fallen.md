We'd see it the moment it happened, overnight they'd end up switching
crowds.

The teachers, who were supposed to be their protectors, and their hope and
inspiration, would eventually notice the transition as well, but perversely
they would think to themselves "I was correct, I always knew that one was a
loser too."