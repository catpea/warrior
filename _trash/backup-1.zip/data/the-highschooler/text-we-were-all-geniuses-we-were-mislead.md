We were taught that genius is rare, that creativity is reserved for those
who have talent, that good grades get a good job, that only the smart ace
the tests, and that to pass a test we need to cram harder and take more
notes, that grade-point-average is the measure of a human - because that is
how the world works.

And work...

Work would set us free.

We were scared, because there was no road ahead. There was no clear
authentic future.

Not without that same charade, that inauthenticity, that glass of fashion,
that mold of form that we were being pressed into, and everyone else
already accepted, and blindly participated in.