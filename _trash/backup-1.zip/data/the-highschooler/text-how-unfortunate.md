"Focus on the positive, on how hard we work and how far we've come
together." - They'd say, ever so lovingly.

Void of context, many of the shallow arguments the teachers made could
almost stand up to a proper debate.

But we remained unconvinced because teaching is not just a job. It is not
an ordinary job, and it is not just about knowledge.