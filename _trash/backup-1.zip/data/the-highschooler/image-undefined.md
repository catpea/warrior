A picture of a real blackboard in a library taken from [F\*\*k Grades by
Denise Dutton][1].

Prof. Dutton does not postulate a 2.\* GPA student in her talk.

I think the person that wrote this was a young woman. And this might have
been her last act of defiance in that school.

We lost a wise and delicate being, a leader, a scientist, maybe a writer,
to silence, rejection, shunning.

That late-night scribble is clear Evidence of Exceptional Ability. This is
someone we each admire, someone Beautifully Courageous.

But she left, she's gone. They gave her a 2.0 for Leadership,
Unbreakability, Heroism, for spending her last semester reading books she
loved, at the school library she loved, right before getting thrown out.

Thrown out by people that didn't know what they were doing, but they sure
as hell worked hard at doing it.

Thrown out for unobstructed pursuit of Wisdom.

[1]: https://www.youtube.com/watch?v=xz-gVKwWNzs