Teaching requires that the Teacher first comprehends each of the Students,
understands their existing body of knowledge, manner of learning, and finds
a way to genuinely communicate with them.

Tracking is not that hard, a pencil or a Concept Mapping tool will do.