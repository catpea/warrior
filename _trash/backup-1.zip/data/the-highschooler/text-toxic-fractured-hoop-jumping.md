School doesn't just kill creativity, genius, talent, inspiration and
passion, it kills learning too.

The toxic mixture of irrelevant babble, easy to cram for tests, and Life &
Career threatening GPA; forces the student to abandon Authentic Education
for curriculum-hoop jumping.