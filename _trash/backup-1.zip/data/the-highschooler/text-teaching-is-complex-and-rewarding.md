Teaching should respectfully extend their existing knowledge. The teacher
must know if fascination with Dinosaurs will head towards Paleontology,
Biology, Ecology, and keep an eye on progression of that path (if said path
continues) to see is they have a Cell Bilogist, Astrobiologist,
Evolutionary Biologist, or maybe a Writer, in their class.

The complexity of teaching may actually scale with the reward, how
fantastic it must be to help our Dino Girl to ponder inter-planetary
cross-contamination from the Chicxulub crater and witness her journey lean
towards Astrobiology and an internship at NASA/ESA, possibly a career.

Now, pushing her away from what moves her, grading her down for it, and
forcing her to memorize whatever is in the curriculum so that she may pass
the grade. That is something else... And the answer to how many children
were hurt this way, is: **all of them**, in every school, on every
continent, in every country, state and district.

Schools interrupt education.

They destroy careers, passions, inspirations, talents, and genius. They do
it just a split second before the Kids know how to protect it.

They destroy The Shy, The Delicate, The Compassionate.

They destroy Pacifists, Leaders, Scientists, Inventors, Dreamers, Poets,
Artists, Sculptors, Musicians, Adventures, Writers, Makers, Heroes.