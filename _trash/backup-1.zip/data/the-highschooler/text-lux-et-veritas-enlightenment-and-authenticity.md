Above all, school is a place of healing, it is a sacred place.

The School Library is even more sacred, it is a place for Young
Philosophers.

School is about safety and security and protection, first.

It must be a place where we can safely grow, study both Life, and Wisdom.
Search for Enlightenment and Authenticity.

Education is about mental health, learning to live.

Learning to avoid what is not life.

Not starting at zero, but rather resuming at where the greatest minds left
off.

The teachers were supposed to work for us first. Only upon genuinely
enabling us to comprehend new things, should they be rewarded.