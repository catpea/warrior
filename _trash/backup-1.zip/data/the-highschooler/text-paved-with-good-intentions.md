They meant no harm, they did it so that they could get paid, so that the
school could get funding, so that everyone would keep their job. But those
who didn't rise against it caused harm. They interfered with our real
education, harming creativity, erasing individuality.

In K-12 they taught us that delicate hearts belonged with mommy at home,
that bullies were a fact, and life is never fair. They hurt our hearts, and
shamed us by saying. "Oh, just grow up, already! Because, you need to
improve your grades."