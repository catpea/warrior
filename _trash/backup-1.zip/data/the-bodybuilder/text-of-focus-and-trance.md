The staying in the moment that he describes can be induced with a fun and
snappy playlist, where non-stop endurance bodybuilding is concerned. I
don’t mean to trivialize what he is describing, ultramarathons are
different from endurance workouts, they take longer and you certainly don’t
want to depend on your mp3 player to finish. At the same time
ultramarathons have relative silence and it is easier to focus in the
middle of an interesting run, or pretty dessert; than a gym. I would add
that during my jogging days I had success with “separating” my mind from my
body, by thinking of my body as a good horse, that will serve well as long
as it is treated well.