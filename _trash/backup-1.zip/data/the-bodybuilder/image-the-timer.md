Interval timer will vibrate on start and stop of both exercise and rest. It
will count down the number of exercise-rest sequences. By gradually
lowering rest period and increasing exercise-rest sequences you will easily
increase your endurance.