Raising your legs, raising your upper body, curving your spine will let
your body rest. A flat mattress will attempt to straighten the natural
curve to your lower back, in combination with lifting weights for prolonged
periods, this is a recipe for disaster. You must let your back-muscles
relax.