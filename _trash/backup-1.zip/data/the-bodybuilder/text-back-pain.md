Significant Injuries are more likely if you lift heavy. If you lift heavy a
few times, your muscles will not be in a flexible enough state to handle
it. Eventually you will pull a muscle, hurt yourself. If you lift 5lb
10,000 times, the chances of getting hurt are much lower. Back pain is
still likely to occur, you will need a proper bed, I use the inexpensive
[PragmaBed][1]

[1]: http://pragmabed.com/