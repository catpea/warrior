While our cooling is superior, we do lose electrolytes while we sweat, you
need to put them back in. V8 vegetable juice which contains both sodium and
potassium is one way to do so, but always with wisdom and in moderation.