Bodybuilding is a side-effect of something more. Like Confidence, or
Happiness, or Success, it will ensue from pursuit of things that seem just
out of your reach.