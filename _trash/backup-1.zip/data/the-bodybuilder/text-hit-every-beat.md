There is no struggle because of music, the parts of your brain that are
telling you to stop are weak. They are weaker than the beat of drums, they
are weaker than a pretty song.

Workout to the beats of songs, here is a player I eventually settled on:
[Professional MP3 HIFI Music Player][1] it costs US $24.80 it is OK, I
think. It does not seem Professional, I think it is just because phones are
really good these days.

[1]: https://www.aliexpress.com/item/32980109852.html?spm=a2g0o.productlist.0.0.4efc7ec7pkt8Ur&algo_pvid=121e3087-e613-4dcc-af88-ba55a993e258&algo_expid=121e3087-e613-4dcc-af88-ba55a993e258-1&btsid=9e653dc7-cf62-4fce-8d37-51985af20013&ws_ab_test=searchweb0_0,searchweb201602_10,searchweb201603_52