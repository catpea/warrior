Blanco Brown: [The Git Up][1]

Taylor Swift: [Shake It Off][2]

Psy: [Gangnam Style][3]

Davay: [Tri Poloski][4]

XS Project: [Bochka Bass Kolbaser][5]

Lil Nas X: [Old Town Road][6]

Pitbull: [Timber][7]

Ciara: [1 2 Step][8]

Lorde: [Royals][9]

Fort Minor: [Remember The Name][10]

Imagine Dragons: [Believer][11]

Macklemore: [Can’t Hold Us][12]

Billie Eilish: [Bad Guy][13]

Kesha: [Blow][14]

Beyonce: [Single Ladies][15]

Cascada: [Evacuate The Dancefloor][16]

Blade: [Blade 1 Vampire Dance Club Theme][17]

Smile: [Butterfly][18]

Infernal: [From Paris To Berlin][19]

XS Project: [Expressway][20]

Charlie Puth: [Betty Boop][21]

Caravan Palace: [Wonderland][22]

Valentino Khan: [Pump][23]

LMFAO: [Sexy and I Know It][24]

[1]: https://www.youtube.com/watch?v=Q7U6AoZ27yE
[2]: https://www.youtube.com/watch?v=nfWlot6h_JM
[3]: https://www.youtube.com/watch?v=9bZkp7q19f0
[4]: https://www.youtube.com/watch?v=Y8qtmD_QTYw
[5]: https://www.youtube.com/watch?v=VLW1ieY4Izw
[6]: https://www.youtube.com/watch?v=Ub3JtYKuMtA
[7]: https://www.youtube.com/watch?v=hHUbLv4ThOo
[8]: https://www.youtube.com/watch?v=iBHNgV6_znU
[9]: https://www.youtube.com/watch?v=nlcIKh6sBtc
[10]: https://www.youtube.com/watch?v=VDvr08sCPOc
[11]: https://www.youtube.com/watch?v=7wtfhZwyrcc
[12]: https://www.youtube.com/watch?v=2zNSgSzhBfM
[13]: https://www.youtube.com/watch?v=DyDfgMOUjCI
[14]: https://www.youtube.com/watch?v=3yIDXlYMcnE
[15]: https://www.youtube.com/watch?v=4m1EFMoRFvY
[16]: https://www.youtube.com/watch?v=A68j28KQaik
[17]: https://www.youtube.com/watch?v=cNOP2t9FObw
[18]: https://www.youtube.com/watch?v=QzcvRDWgRIE
[19]: https://www.youtube.com/watch?v=zgurcTTsIv0
[20]: https://www.youtube.com/watch?v=K3T0FNowHwg
[21]: https://www.youtube.com/watch?v=sd6_PHCdCZI
[22]: https://www.youtube.com/watch?v=vCXsRoyFRQE
[23]: https://www.youtube.com/watch?v=3_twoy0qdOk
[24]: https://www.youtube.com/watch?v=wyx6JDQCslE