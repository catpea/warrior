Your body will trick you into stopping too early if you rely on counting.
Interval Timers remove the distraction of constantly asking "Is it enough",
and help you switch to "I will make it to the end".

Use the beat of songs to further distract yourself from quitting. You will
not gain endurance if you stop when your body begins hurting, you have to
signal your body that is has to adapt because there is no stopping.

Remember, you must signal your body that adaptation to exertion is
required. You must not allow your body to force you to stop as that will
void the exercise and your body will not receive any adaptation signals.

No adaptation signals, no change to your strength and endurance.