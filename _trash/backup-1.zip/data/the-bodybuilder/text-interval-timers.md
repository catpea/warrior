If you need precision use [this tool][1] to get a BPM on a song to make a
playlist, and if you are still having difficulty with non-stop exercise
despite a chain of slow songs, then use a computer to keep track of your
rests. I used an Interval Timer from [https://www.gymboss.com/][2]

Keep lowering that rest period until no rest is needed in your routine.

[1]: https://www.all8.com/tools/bpm.htm
[2]: https://www.gymboss.com/