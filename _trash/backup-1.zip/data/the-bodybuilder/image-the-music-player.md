Distraction free with easy to push control buttons and large accessible
volume knob.