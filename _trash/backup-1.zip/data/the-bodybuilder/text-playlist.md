I change my playlist daily, here are some examples.

[Electro Bounce][1]

[Boosted Bootleg][2]

[Bass Boost][3]

[HIIT Songs][4]

[Bubblegum Pop][5]

[Dance Pop][6]

[Hardstyle][7]

[Hard Bass][8]

[Powerstomp][9]

[Industrial][10]

[EBM (Electronic body music)][11]

[Synthpop][12]

[Witch House][13]

[Aggrotech][14]

[Choreography][15] (choreographers tend to pick amazing songs).

[1]: https://www.youtube.com/results?search_query=Electro+Bounce
[2]: https://www.youtube.com/results?search_query=Boosted+Bootleg
[3]: https://www.youtube.com/results?search_query=Bass+Boost
[4]: https://www.youtube.com/results?search_query=HIIT+Songs
[5]: https://www.youtube.com/results?search_query=Bubblegum+Pop
[6]: https://www.youtube.com/results?search_query=Dance+Pop
[7]: https://www.youtube.com/results?search_query=Hardstyle
[8]: https://www.youtube.com/results?search_query=Hard+Bass
[9]: https://www.youtube.com/results?search_query=Powerstomp
[10]: https://www.youtube.com/results?search_query=Industrial
[11]: https://www.youtube.com/results?search_query=EBM
[12]: https://www.youtube.com/results?search_query=Synthpop
[13]: https://www.youtube.com/results?search_query=Witch+House
[14]: https://www.youtube.com/results?search_query=Aggrotech
[15]: https://www.youtube.com/results?search_query=Choreography