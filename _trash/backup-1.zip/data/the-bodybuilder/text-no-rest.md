Finally we arrive to the point where I explain why you can’t take days off.
Think of your body as a good horse to your mind. Take two horses with
muscle atrophy, one walks ten steps three times, every other day weekends
off, the other trots for eight and half hours every day for many years, no
day off. Which horse would you bet on, which horse would have more muscle,
which horse would live healthier?