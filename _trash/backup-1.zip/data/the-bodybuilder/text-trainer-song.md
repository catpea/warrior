I also created an Open Source (Free) workout instruction drum song, the mp3
files are available here:
[https://github.com/westland-valhalla/drums/releases][1]

[1]: https://github.com/westland-valhalla/drums/releases