Perhaps some of you may find working out with vocals easier, if so then the
[Backyard Sessions][1] come to mind.

[1]: https://www.youtube.com/watch?v=iFZsunzjDXU&list=PL6A17A25BE19EA6E9