The Web Developer, that you need to become creates the streamlined,
low-liability versions of [wrapbootstrap.com][1], [themes.shopify.com][2],
or even [shopify.com][3] it self, and others that tickle your fancy in
similar ways.

Now when I went to the website of INSPINIA developers, I got redirected to
wrapbootstrap.com. This may mean - and in deed it would make perfect sense
- that WrapBootstrap made INSPINIA. This would also mean that they made 2.2
Million Dollars, they pocketed 100% of those sales ([3rd party sellers earn
80%][4]).

Your story may be even more elaborate than this. You maybe taking a step
above the platforms, and sell a service where a person can rent a platform
like [wrapbootstrap.com][5] or [themes.shopify.com][6] for a monthly
membership fee and a reasonable percentage of sales.

[1]: wrapbootstrap.com
[2]: https://themes.shopify.com/
[3]: https://shopify.com/
[4]: https://support.wrapbootstrap.com/help/fee-structure
[5]: wrapbootstrap.com
[6]: https://themes.shopify.com/