Web Developer, is a huge step. But making themes is not it. It is not even
about learning programming, though you should definitely know about it;
because you need a team of programmers to develop your sales platform(s).

It is about becoming a Businessperson with a plan. In other words, a
Founder, a CEO.

You shouldn't think of a web developer as a person that merely develops for
the web, think of one as a developer of the web. That is a difference
between $180 and $2,200,000, a resume and an outstanding portfolio, an
employee and an employer, bugfixes and excitement.