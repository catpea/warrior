Below is the text from [Love building themes? Join the Theme Store
community at Shopify][1], where website themes sell for $180.

(If you think you can handle this, go for it! Though, please note that they
are gently asking that you have a team, which could mean outsourcing, and a
budget for bug fixing. The platform for managing your outsourced team would
be [github][2] and [slack][3], this is doable you could even experiment
paying your developers via [liberapay][4])

Personally, I see that the posting below has too many restrictions. And if
your theme won't average 10 sales per month, they'll throw it out.

I don't know what their relationship is with [leading web design
frameworks][5]. I don't think they have a rational streamlined pipeline.
Because, what they call bug fixing is a massive undertaking requiring
[dozens of developers][6].

The most widely developed foundation for themes, after many years of
development had [60 issues][7] last month alone (November 2019).

[1]: https://themes.shopify.com/services/themes/guidelines
[2]: https://github.com/
[3]: https://slack.com/
[4]: https://liberapay.com/
[5]: https://github.com/topics/css
[6]: https://github.com/twbs/bootstrap/graphs/contributors
[7]: https://github.com/twbs/bootstrap/pulse/monthly