Thinking flat is about simplicity, and sometimes layers. In 3D Printing we
think in layers of plastic; in Laser Cutting we can think in layers of
whatever you are cutting.