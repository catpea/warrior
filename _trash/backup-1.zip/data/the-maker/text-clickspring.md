[YouTube Channel][1]

[Making The Antikythera Mechanism][2]

[Making A Large Wheel Skeleton Clock][3]

[1]: https://www.youtube.com/channel/UCworsKCR-Sx6R6-BnIjS2MA
[2]: https://www.youtube.com/playlist?list=PLZioPDnFPNsHnyxfygxA0to4RXv4_jDU2
[3]: https://www.youtube.com/playlist?list=PLZioPDnFPNsETq9h35dgQq80Ryx-beOli