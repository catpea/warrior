The [price][1] of the CNC plasma cutter used in [MAKE IT REAL][2] videos
below ranges from $30,000.00 - $45,000.00, pro version is up to $92,000.00

As the part 2 says, having someone else run cutter is actually reasonably
priced.

Visit the [the Hacksmith][3] YouTube Channel for more.

[1]: https://www.maverickcnc.com/pricing-page/
[2]: https://www.youtube.com/watch?v=2RVyE1wlH7E
[3]: https://www.youtube.com/channel/UCjgpFI5dU-D1-kh9H1muoxQ