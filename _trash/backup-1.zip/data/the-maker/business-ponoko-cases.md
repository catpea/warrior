A great example of flat layers adding up to create more than just flat
thing are Raspberry PI cases.