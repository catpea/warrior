A small desktop sized waterjet is about $8,000.00, take a look at
[Wazer][1] It can cut 0.120" Stainless Steel, Marble, Boro Glass, HDPE,
Silicone, and Carbon Fiber.

Here is a small business example based on a large waterjet
[waterjetknives.com][2]

Visit [Cut in Half][3] and [Waterjet Channel][4] for more shenanigans.

[1]: https://www.wazer.com/
[2]: https://waterjetknives.com/
[3]: https://www.youtube.com/channel/UCZ9gllpxg63WTW10FcydrHA
[4]: https://www.youtube.com/channel/UCY2--S73K_Ce6uvmN9UXvlw