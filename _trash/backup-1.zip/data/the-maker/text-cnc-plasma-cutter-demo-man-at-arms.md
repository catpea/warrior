[Man At Arms][1] use a similar cutter, but tend to use the resulting product as a template/test for real blacksmithing.

[1]: https://www.youtube.com/playlist?list=PLUUGFk1wE5OFOpfPz3ggXQrCSdQdFEslx