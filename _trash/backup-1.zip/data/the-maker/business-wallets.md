A good example of a flat cut product that makes good money, is the wallet!

[Kickstarter][1] has an article about wallets [Why are there so many wallets on Kickstarter?][2] Take a look at [Trayvax][3] and [Dango Products][4] for more ideas.

[1]: https://www.kickstarter.com
[2]: https://www.kickstarter.com/stories/wallets
[3]: https://www.trayvax.com/
[4]: https://www.dangoproducts.com/