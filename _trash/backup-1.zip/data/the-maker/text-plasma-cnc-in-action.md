You can see the Plasma CNC in action at [4:03][1]

[1]: https://youtu.be/vef62MzS6as?t=243