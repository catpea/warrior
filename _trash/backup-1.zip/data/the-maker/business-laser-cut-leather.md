Sarah Kirkham and Anna Warren created a [Leatherworking][1] business where
they use a laser cutter to create fancy products.

Consider creating a similar business (see [The Founder][2])

[1]: https://en.wikipedia.org/wiki/Leather_crafting
[2]: founder.html