The beginning of self education starts with a class of teachers often
called Science Popularizers. They don’t just teach science, but also
restore the connecting lines between all the Daughters of Philosophia,
lines lost due to the bleaching effect that categorization of knowledge,
standardization of sequence of learning, and standardized testing causes.

The Storytelling of Science is a good overview of who these teachers are,
how they think, of their energy and class.