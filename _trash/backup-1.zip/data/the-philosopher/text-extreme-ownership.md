I think that some day we maybe able to find great schools, and people like
Sir Robinson will help that day come. But it will be too little too late,
certainly for us. In this final chapter I will ask you to take Extreme
Ownership of Your Education, and here is Jocko Willink explaining the
gravity of the words Extreme Ownership.