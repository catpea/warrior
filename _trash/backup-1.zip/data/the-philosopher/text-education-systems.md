Sir Ken Robinson, in his “How to escape education’s death valley” states
that the more successful Alternative Education Systems should become the
norm, because they are clearly more successful.