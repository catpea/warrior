[Audiobook version of A People’s History of the United States][1] is 34 hrs and 8 mins long.

Abridged version (8 hrs and 44 mins ) read by Matt Damon is here: [A
People’s History of the United States][2]

[1]: https://www.audible.com/pd/A-Peoples-History-of-the-United-States-Audiobook/B0030H777E
[2]: https://www.audible.com/pd/A-Peoples-History-of-the-United-States-Audiobook/B002V5CKGE