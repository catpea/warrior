Education is simply too important to be put in someone else’s hands. It is
your mind, your life, your growing up, your own responsibility. Above all,
your body of knowledge has massive infuence over your private
decision-making, over your freedom of choice, over your freedom of will.
Decision-making is one of the most sacred things in life, and only you
should have control over that.

I urge you to forget the idea that you must be taught to learn. I urge you
to accept that great responsibility yourself. You must take extreme
ownership of your own Self Education.