[Philosophy][1] (from Greek φιλοσοφία, philosophia, literally “love of wisdom”) is the study of general and fundamental questions about existence, knowledge, values, reason, mind, and language. Philosophia has been called The Mother of All Sciences.

[1]: https://en.wikipedia.org/wiki/Philosophy