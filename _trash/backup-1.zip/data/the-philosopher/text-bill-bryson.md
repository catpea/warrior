[A Short History of Nearly Everything][1] Audiobook. [The Body][2] (His latest book). All of Bryson’s [Audiobooks][3].

[1]: https://www.audible.com/pd/A-Short-History-of-Nearly-Everything-Audiobook/B002V0KFPW
[2]: https://www.audible.com/pd/The-Body-Audiobook/0147526922
[3]: https://www.audible.com/author/Bill-Bryson/B000APXTVM