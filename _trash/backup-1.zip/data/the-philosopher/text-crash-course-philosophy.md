[47 Video YouTube Playlist][1]

[1]: https://www.youtube.com/playlist?list=PL8dPuuaLjXtNgK6MZucdYldNkMybYIHKR