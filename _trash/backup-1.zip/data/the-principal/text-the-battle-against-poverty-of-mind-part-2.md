What can be easier than to help a child grow?

what can be more rewarding than to be Admired, Loved, Remembered? To have a
High School named after you upon your retirement, and have every student
that goes there at least look at your picture with your beloved students
hugging you as if you were their own Mother.