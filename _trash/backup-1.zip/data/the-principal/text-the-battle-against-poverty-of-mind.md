It is correct to say that Poverty of Mind is rooted in lack of Non
Cognitive Skills.

An example of poverty of mind is inability to have an expensive lunch with
an internship company CEO. Out of fear of not knowing **EVERYTHING!** from
how to get a table to when to order, or even if it is OK to just have the
cute little bagel and focus on the questionnaire. Lunch, if not impossible,
can be impossibly terrifying.

There is no breaking out of poverty when every-step induces fear,
confusion, anxiety.

To be clear, the ultimate aim for both Student and Principal. Almost
always, is to rise and break away, become a CEO.

Become an inspiration and a teacher; to make life more. To then retire come
the Golden Age of Wisdom and write. Write about the lessons that counted to
make them last even longer. Create an Audio Book in your own voice in hopes
of it being used 50 years from now to Rise & Learn to Really Learn. What an
Honor to have your spirit revived by means of Admiration and Love, your own
voice across decades, maybe centuries, maybe forever.

Instead, the children are getting scared, mostly because they can see
schools are forcing irrelevant learning that fades away. It is impossible
to retain irrelevant knowledge. In context of education, forcing irrelevant
knowledge and grading a student down for lack of retention is evil.

And here the child does not want the job because it has too many
complications, can't even have the internship lunch because it is too
terrifying, and can't conceive of the notion of connecting with the CEO in
such a way as to eventually resign position and start a company in a
similar sector.

They are scared, sometimes crushed, but far too brave to show you...
Principal.

We know what happens to most young people that can't handle fear or
depression.