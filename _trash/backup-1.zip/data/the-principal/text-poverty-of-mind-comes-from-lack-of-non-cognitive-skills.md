Dan Cardinali's definition of Non Cognitive Skills includes the following:
Building grit, and resilience, and persistence, and self-regulation. He's
describing skills of a Warrior, a Fighter, an Authentic Grown Up.

Dan Cardinali explains that ideally families should provide Non Cognitive
Skills (Child Development), and then schools will deliver Academic
Development (Math, History, Physics).

But this is not how it works today, well to do parents are too busy,
parents stricken by poverty can't have time, and non-cognitive skill
development is not only unavailable, but is often laughed at by teachers
"Parents do your job." they brainlessly utter.

Above all, a child born to the culture of poverty (lacking non-cognitive
skills) will often remain in the culture of poverty be it dropping out or
graduation. The steps out and up are just too far apart.