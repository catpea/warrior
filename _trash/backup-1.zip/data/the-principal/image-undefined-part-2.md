Image from [Can anyone become a genius? by Mark Diaz][1]

[1]: https://www.youtube.com/watch?v=mQPEZdBTOeE