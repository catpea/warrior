Focus on Real Education, not Administration. If you need money, then look
to your students.

Become a Start-up Accelerator. Give them initial mentoring and funding,
Take a small percentage of their earnings in return for the initial funding
and in order to fund other start-ups. Take only for a small number of
years, and only what you need. Get out of their way.

Never forget, Principal. You serve The Kids, The Students, they are the
point of it all, they are the future. The Children are not your means to
staying in business and getting paid- that would make you a Monster and a
Fraud.

The best way to fight poverty in a person's mind, is to set a student up
for a job so high up, that it will make them want to run out of the school
quietly-yelling and hope they never need to come back.

A prestigious position at a local Hospital as a Research Nurse that keeps
everyone informed a month ahead of time, a complicated job at the Library
of Congress, or as Someone Amazing at the Detroit Institute of Arts.

Set a step so high, that it is already a healthy career but completely
unreachable to the child, the step up being, Just Impossible. And then
slowly, build. But smaller steps, and maybe even smaller, or maybe even an
on-ramp for a smooth ride.