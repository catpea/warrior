Be it by intent or ignorance, anybody taking part in the fracturing of
minds, and young minds especially, is just another monster.

A school must become a place of healing before it can hope to teach.

It must protect against all kinds of poverty, and bad parents, dangerous
culture and bad ideas.

Today school is a bad place. Just another broken promise.