How dare you.

How. Dare. You.

Image from [The Surprising Truth About Learning in Schools by Will
Richardson][1]

[1]: https://www.youtube.com/watch?v=sxyKNMrhEvY