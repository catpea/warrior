It is not just "grit, and resilience, and persistence, and
self-regulation", Dan Cardinali shows that Talitha Halley had enormous
amount of help beyond Belief and Love which is already wonderful. Donna
Watkins (Talitha's community-school site coordinator) looked for **every
developmental opportunity**.

Talitha must have said she was scared to go to the Fancy Lunch and Donna
came to her rescue, that is so brave and so sweet.