\[My\] recruiting does not have anything that says "Requires University"
because that's absurd, but there is a requirement of evidence of
exceptional ability. \[...\] I don't consider going to college evidence of
exceptional ability in fact ideally you dropped out and did something
\[exceptional\].