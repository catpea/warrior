Newton's Orbital Cannon is on [page 518][1].

[1]: https://archive.org/stream/newtonspmathema00newtrich#page/n517/mode/2up