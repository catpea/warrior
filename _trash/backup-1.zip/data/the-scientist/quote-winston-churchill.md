Success is not final, failure is not fatal: it is the courage to continue
that counts.