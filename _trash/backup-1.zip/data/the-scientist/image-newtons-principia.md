To paraphrase Alexander Pope "Nature and Nature's laws lay hid in night:
Thus Nature said, Let Newton be! and all was light." You can find a
translated digital copy of Newton's Principia [here][1].

[1]: https://archive.org/stream/newtonspmathema00newtrich