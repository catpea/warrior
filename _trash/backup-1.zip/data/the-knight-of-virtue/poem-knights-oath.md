The right can never die, If one man still recalls, The words are not
forgot, If one voice speaks them clear, The code forever shines, If one
heart holds it bright.

The knight is sworn to valor, His heart knows only virtue, His blade
defends the helpless, His might upholds the weak, His words speak only
truth, His wrath undoes the wicked.