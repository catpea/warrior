As we grew so did our grasp on the Human Condition, from bloody and warring
clans of duty and loyalty a new kind of class emerged.

The Knight of Virtue.

Internal influences are as just as powerful at changing a human, as the
external ones. To internalize Knightly Virtues, to live by them, to triumph
by them, became a sure way to become a hero.

**Forbearance, Hardihood, Largesse, Benevolence, and Honour.**