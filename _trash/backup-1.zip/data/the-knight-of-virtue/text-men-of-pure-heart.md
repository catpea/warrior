Superheroes like [Galahad][1] carried a message that put servitude second.
For one cannot uphold the Knightly Virtues whilst blindly following orders
issued by someone who does not strive to uphold them.

[1]: https://en.wikipedia.org/wiki/Galahad