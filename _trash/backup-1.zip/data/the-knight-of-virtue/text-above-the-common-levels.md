By subtle analogy to high pursuits in modern era, we can estimate that to
aim for greatness, to climb the highest of mountains built Hardihood,
enabled Largesse, taught Benevolence, and helped with Honour.

The stories of Virtuous Knights are journeys of pursuit of knowledge, and
self discovery, of trials and tribulations, of overcoming and rising, of
triumph and disaster.

To search for the Grail, or Arthur, Percival, or Galahad, and the others;
was to find the Knightly Virtues and Wisdom set to timeless songs and poems.