Chivalry! - why, maiden, she is the nurse of pure and high affection, - the
stay of the oppressed, the redresser of grievances, the curb of the power
of the tyrant - Nobility were but an empty name without her, and liberty
finds the best protection in her lance and her sword.