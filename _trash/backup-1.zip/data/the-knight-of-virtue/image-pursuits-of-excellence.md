What we know of the superheroes of middle ages comes from poems and
recreations of the lost arts.