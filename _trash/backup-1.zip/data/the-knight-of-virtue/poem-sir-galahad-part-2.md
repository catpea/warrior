My good blade carves the casques of men,

My tough lance thrusteth sure,

My strength is as the strength of ten,

Because my heart is pure.