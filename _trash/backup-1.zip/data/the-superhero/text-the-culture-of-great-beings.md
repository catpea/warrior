Don’t be scared to save the world. Mind is a Reflex Organ, Soc says, and he
is right. We must be in charge of ourselves. We have to take out the trash.
And, at night, when everything comes at you and wakes you up at 3:13am when
you are not ready to fight back, you can always turn on an Audiobook by
Bill Bryson, Carl Sagan, or the lovely Sarah Vowell. Night by night, the
culture of great beings will add to your culture. On the shoulders of
giants also means that come your Golden Age, there will be little heroes
checking if you have risen high enough for them to stand on your shoulders.