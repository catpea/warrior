Dan Millman, wrote a book in which he featured him self as a character,
next to the imaginary wise man Socrates, Soc for short. Dan is someone who
quite literally pulled him self up by his own shoe laces.

Here is [Way of the Peaceful Warrior Audiobook][1] narrated by the man
himself. It was also made into a movie starring Nick Nolte as Soc.

[1]: https://www.audible.com/pd/Way-of-the-Peaceful-Warrior-Audiobook/B002UZKKSU