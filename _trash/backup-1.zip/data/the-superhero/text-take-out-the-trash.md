Dan Millman, teaches us to take out the trash, to erase doubt, negativity,
fear, keep moving forward and become Vulnerable and Fearless Warriors.