[A Short History of Nearly Everything][1]

[A Walk in the Woods, Rediscovering America on the Appalachian Trail][2]

[I’m a Stranger Here Myself, Notes on Returning to America After 20 Years Away][3]

[The Demon-Haunted World, Science as a Candle in the Dark][4]

[Assassination Vacation][5]

[1]: https://www.audible.com/pd/A-Short-History-of-Nearly-Everything-Audiobook/B002V0KFPW
[2]: https://www.audible.com/pd/A-Walk-in-the-Woods-Audiobook/B0091J9AQQ
[3]: https://www.audible.com/pd/Im-a-Stranger-Here-Myself-Audiobook/B002V5BQJQ
[4]: https://www.audible.com/pd/The-Demon-Haunted-World-Audiobook/B06XTZZLZ8
[5]: https://www.audible.com/pd/Assassination-Vacation-Audiobook/B002V8N0VK