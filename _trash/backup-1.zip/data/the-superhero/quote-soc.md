A warrior is not about perfection. Or invulnerability. He is about absolute
vulnerability. That’s the only true courage.