There is a similar theme in No retreat No surrender, where the boy calls
upon Sensei Lee, to come an teach him.