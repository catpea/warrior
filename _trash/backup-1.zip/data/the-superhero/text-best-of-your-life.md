Come morning, it does not matter how old you are, or how many times you
failed already, the rest of your life is always ahead of you. **Make the
rest of your life, the best of your life.**