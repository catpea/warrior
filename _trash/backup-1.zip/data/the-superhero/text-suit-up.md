Put on the Superhero Suit and step into the arena, right now. Being ashamed
to dance, or waiting until you are perfect to face your next challenge, are
just illusions that are holding you back.

You are each to become a Great Being. The world needs Superheroes.