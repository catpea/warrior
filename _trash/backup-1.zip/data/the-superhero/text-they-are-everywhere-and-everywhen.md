Erica Goldson carries on her message and self-education, aiming to inspire
and help the world grow. She discovered the absence of teachers early on,
and immediately became an educator her self.