By whatever means necessary, risky, or imaginary, we have to keep going
forward, up, up, and away, and all the way up, until we become the beings
that we once thought the adults already were.

Reaching out for wisdom, standing in relentless pursuit of excellence is
not optional. Without growing up we will become weak or ill, and face those
circles again.