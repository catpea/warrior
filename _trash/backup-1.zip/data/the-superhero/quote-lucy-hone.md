"Number One: Resilient people get that \[terrible disasters do happen\],
they know that suffering is part of life, this doesn't mean they actually
welcome it \[...\] just that when the tough times come they seem to know
that suffering is part of every human existence and knowing this stops you
from feeling discriminated against when the tough times come."

"Number Two: Resilient people are really good at choosing carefully where
they select their attention. They have a habit of realistically appraising
situations, and typically managing to focus on the things that they can
change, and somehow accept the things that they can't."

"Make an intentional deliberate ongoing effort to tune in to what's good in
your world."

"Number Three: Resilient people ask themselves "Is what I'm doing helping
or harming me?" this is a question that's used a lot in good therapy."

"Is what I'm doing helping or harming me?"