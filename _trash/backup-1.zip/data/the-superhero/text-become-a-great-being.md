Be it fixing schools, or erasing borders, or just preventing Anthropocene
from becoming an [extinction event][1] it will take a Great Being to be
heard, Greta Thunberg is a wonderful example, today.

[1]: https://en.wikipedia.org/wiki/Holocene_extinction