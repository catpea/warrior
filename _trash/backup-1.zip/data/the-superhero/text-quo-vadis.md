Please note that monitoring where each of your steps is taking you, whether
it is good or bad for you, will help you navigate life and improve your
decision making.

Quo Vadis? My friends.