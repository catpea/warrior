Never give up, whatever your calling, never retreat, never surrender. And
in the absence of teachers, you become the teacher. Sure, maybe [anything
that can go wrong will go wrong][1] but that’s just the next challenge,
your next level up. An opportunity to stand even taller.

[1]: https://en.wikipedia.org/wiki/Murphy%27s_law