Here, we come to today, the modern times. In the battle between the
Gentleman and The Officer. The Gentleman was lost. The honor code is no
longer aimed at Men, it is now aimed at cadets, aimed away from the public.
It almost seems like growing up is optional, and things get very strange in
deed: