We the warriors in pursuits of excellence, band together in sincerity and
truth.

May our philosophy be filled with power and may we connect in authenticity.

May we strengthen and increase our admiration for honest dealing and clear
thinking, and may our hatered of hypocrisy and pretence never diminish.

May we inspire each other in our endeavor to live above the common levels
of life.

May we strengthen each other to choose the harder right instead of the
easier wrong, and never to be content with a half truth even if the whole
can’t be won.

May we endow each other with courage that is born of loyalty to all that is
noble and worthy, that scorns to compromise with vice and injustice and
knows no fear when truth and right are in jeopardy.

May we guard each other against flippancy and irreverence in the sacred
things of life.

May we grant each other new ties of friendship and new opportunities for
leadership or service.

May we kindle our hearts in fellowship with those of a cheerful
countenance, and soften our hearts with sympathy for those who sorrow and
suffer.

May we help each other to maintain Honor untarnished and unsullied and to
show forth in our lives the ideals we learned in doing our duty.

All of which we ask in the names of those before us, of those who stand
today, and those who are yet to rise.