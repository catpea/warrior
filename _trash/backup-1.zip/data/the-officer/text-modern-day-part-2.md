At times like these, where our greatest lessons are forgotten we must look
back at where things got lost. At times like these the Knigtly Virtues ring
again. As the poem says _The right can never die, If one man still recalls,
The words are not forgot, If one voice speaks them clear, The code forever
shines, If one heart holds it bright_

I think that one is [Rudyard Kipling][1] I find it delightful that he chose
not to be Knighted, he did not need to look back. Some call him the finest
example of a Gentleman.

His poem “If” is a magnificent reminder that growing up is not optional.

[1]: https://en.wikipedia.org/wiki/Rudyard_Kipling