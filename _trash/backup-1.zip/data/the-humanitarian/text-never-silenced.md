And there are voices that never stopped, fell out of the modern spotlight,
but were never silenced, and never tired. No more circles.