Humanity must break away from the circles. Progress in the larger world,
begins with you, at home, right now. Just the moment you say, “I am not
smart enough”, “I am not a hero”, “I will never be heard”, “I will never be
enough”, “Too Scary!”. That is how every hero begun, by measuring up; and
then by growing up to the challenges before us.