[Bryan Stevenson][1] has helped achieve United States Supreme Court decisions that prohibit sentencing children under 18 to death or to life imprisonment without parole.

[1]: https://en.wikipedia.org/wiki/Bryan_Stevenson