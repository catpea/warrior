I hope we will commit ourselves to building a human rights movement to end
mass incarceration. A movement for education, not incarceration. A movement
for jobs, not jails, and a movement to end all those forms of legal
discrimination against people released from prison. Discrimination denying
them basic human rights to work, to shelter, and to food.