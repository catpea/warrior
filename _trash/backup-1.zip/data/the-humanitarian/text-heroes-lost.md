It is heartbreaking that videos like “Don’t Talk to the Police” must exist.
A Police Officer must also be a Hero, a force of Goodness. Any compromise
between good and evil only hurts the good and helps the evil.