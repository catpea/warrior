[Kandice Sumner's][1] idea beyond share & donate, is **prevention**. She sees young children asking powerful questions. She is trying to help them inherit wisdom from books, stories, history, and push them away from poverty.

[1]: https://www.ted.com/speakers/kandace_sumner