_“Each of us is more, than the worst thing we’ve ever done.”_

_“Our humanity depends on everyone’s humanity.”_

_“Opposite of poverty is justice.”_