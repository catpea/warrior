Poverty, plays a massive role in crime. We learn in this letter that
opposite of poverty is justice, in other words, poverty is an injustice.
Can we serve as an impartial juror, knowing that the defendant would likely
not commit the crime, had they not been fractured by poverty? Every child
has a bright future ahead, Art, Music, Ultramarathons, Astrophysics -
goodness - Combinatorial Genomics, and Astrobiology. But poverty is
extremely corrosive, too corrosive to handle, not only in it self, but in
the surrounding culture that it frequently creates. Poverty is a virus
armed with addiction, abuse, intolerance, xenophobia, violence, and dark
blind stupidity.