73.5 million people in the United States have a criminal record. [Michelle
Alexander][1] wrote a book entitled [The New Jim Crow: Mass Incarceration
in the Age of Colorblindness][2] which is also available as an
[Audiobook][3]

[1]: https://en.wikipedia.org/wiki/Michelle_Alexander
[2]: https://en.wikipedia.org/wiki/The_New_Jim_Crow
[3]: https://www.audible.com/pd/The-New-Jim-Crow-Audiobook/B007QW236E