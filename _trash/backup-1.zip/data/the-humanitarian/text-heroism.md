Don’t be frightened of becoming a hero. It is always the longest possible
way there, and it is always on the shoulders of giants, my friends.

By rising to the challenge, you become part of the family of great heroes,
of great beings. You see, the adults are not going to run the world
forever, by the time you become an adult, they are going to retire.

The job will belong to you. Break out of the circles, and aim up, all the
way up.

All the bad ideas must be left behind, and all the good ideas put in one
place where we can each share in them, where every member of the human
family can Converge on Wisdom.