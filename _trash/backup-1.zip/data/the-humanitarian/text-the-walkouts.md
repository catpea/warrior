December 10th, is [The Human Rights Day][1] and yet again, the hopelessness
turns to hope as we are granted a globally recognized focal point, and an
opportunity to stand on the shoulders of giants.

When this nation is ready, December 10th will become the walkout day. For
District Judges, their staff, Attorneys, their assistants, for Bad Cops,
Good Police Officers, and their COs. On their mind will be the thought,
that to create a life long, legal, discrimination against an individual, is
a Human Rights violation. It should be impossible to ask the legal
community to follow the rule of law in the short term, and violate Human
Rights in the long run.

[1]: https://www.un.org/en/events/humanrightsday/