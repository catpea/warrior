The [Universal Declaration of Human Rights][1] needs work, each generation
needs to update it and extend it beyond what it is today, grant it new
voices - and there are bright new voices to be heard.

[1]: https://librivox.org/the-universal-declaration-of-human-rights-by-the-united-nations/