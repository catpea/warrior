I beg the youngest of you, to arrange your life in such a way so that each
challenge before you, is the hardest thing you have ever done.

To paraphrase Thoreau: I beg you to live and grow up deliberately, to front
only the essential facts of life, to see what love of wisdom has to teach,
and not, when it comes to die, discover that you, my dear friend, had. not.
yet. lived.

Life is not random, it is not an accident, you are an emergent plateau in
an infinity of time ahead. You are needed, and your lasting contributions
are necessary.