The human family is not divided by political borders. Kandice’s kids aren’t
the only kids that need help. This is not just a national crisis, it is a
global one.

[A school under Metro bridge teaches these Delhi slum children][1]

[1]: https://www.hindustantimes.com/delhi/a-school-under-metro-bridge-teaches-these-delhi-slum-children/story-Qr3EV279SarAME4K6N8orL.html