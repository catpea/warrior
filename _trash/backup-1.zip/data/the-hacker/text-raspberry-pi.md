The $35 [Raspberry Pi][1] is the most handsome in a class of computers
called [Single-board computers][2]. They just released version 4, **so make
sure you get that one**; and don’t forget a monitor. BestBuy does sell the
PI, packaged in the [Raspberry Pi 4 Cana Kit][3]. Personally, I think
getting the original keyboard and mouse is really cool, I am not a fan of
the plastic case and would go for a cool looking [Heat Sink “Case”][4] -
and then probably short something out. Good news is that ashens has a two
part review of all the popular cases here you go: [Part 1][5] and [Part
2][6]. Heads up, ashens is an odd British man that utters odd British
phrases.

[1]: https://www.raspberrypi.org/
[2]: https://en.wikipedia.org/wiki/Single-board_computer
[3]: https://www.youtube.com/watch?v=7rcNjgVgc-I
[4]: https://www.amazon.com/dp/B07VD568FB/ref=twister_B07VD58LGV?_encoding=UTF8&psc=1
[5]: https://www.youtube.com/watch?v=zpTlB6oju5w
[6]: https://www.youtube.com/watch?v=rYb2IEsfhnE