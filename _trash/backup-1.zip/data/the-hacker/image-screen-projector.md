Don't forget about [Projectors][1] as those too are a kind of monitor (the
cheap ones are $50 - $75). A projector turns any wall into a monitor.

[1]: https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=projectors