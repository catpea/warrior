This is a glider, a bit of a symbol for hackers, who are like cats, and do
not like each other, herds, or stupid little symbols.