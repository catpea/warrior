Here is Stephen Wolfram in his “Computing a theory of everything” TED talk,
reminding us to **never pause** after uttering the words “I invented a new
kind of science” - Oof!.