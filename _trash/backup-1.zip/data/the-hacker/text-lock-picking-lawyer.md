[Lock Picking Lawyer][1] has 1.14M subscribers (Dec, 2019).

[1]: https://www.youtube.com/channel/UCm9K6rby98W8JigLoZOh6FQ/search?query=combination