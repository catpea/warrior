Lookup [All Your Base Are Belong To Us][1] over at the [Jargon File][2]

[1]: http://www.catb.org/~esr/jargon/html/A/all-your-base-are-belong-to-us.html
[2]: http://www.catb.org/~esr/jargon/html/go01.html