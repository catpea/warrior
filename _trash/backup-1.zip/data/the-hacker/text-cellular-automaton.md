Gliders, are of the world of [Cellular Automaton][1], you have heard Murray
Gell-Mann talk about it in context of [Emergence][2] the Game of Life is a
little simulation of playing with Fundamental Principles, and Accidents.
Life emerged the same way the gliders do, out of Complexity, Infinity of
Time, Fundamental Principles, and Accidents (remember nobody counted the
failed attempts).

[1]: https://en.wikipedia.org/wiki/Cellular_automaton
[2]: https://www.youtube.com/watch?v=ONiWmzrmfuY