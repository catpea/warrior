There is a class of monitors called [Portable Monitors][1] it is still nice
to have a desk one, but if you are wondering which one to get; get a
portable first (the cheapest one is $99), then you can take it to
Starbucks, plug in your PI, keyboard and mouse, and headphones; and
[compose some music][2] with [LMMS][3] whilst [pondering album art][4] with
[GIMP][5].

[1]: https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=+Portable+Monitors
[2]: https://www.youtube.com/watch?v=3qfa9hGJzoY
[3]: https://lmms.io/
[4]: https://www.youtube.com/watch?v=4mgrY-U9_8E
[5]: https://www.gimp.org/