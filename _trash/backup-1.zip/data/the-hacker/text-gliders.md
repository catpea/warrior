The glider comes from [Conway’s Game of Life][1] the little things
manufactured by [Gospers glider gun][2] and walking off towards lower right
are gliders in action.)

[1]: https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life
[2]: https://en.wikipedia.org/wiki/Gun_(cellular_automaton)