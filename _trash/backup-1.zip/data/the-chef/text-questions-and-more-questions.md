[Why Do Some Japanese Restaurants Keep Piles of Salt Outside?][1]

[1]: https://realsalt.com/why-do-some-japanese-restaurants-keep-piles-of-salt-outside/