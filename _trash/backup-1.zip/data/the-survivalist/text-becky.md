[Girl Outdoors Channel][1]

[1]: https://www.youtube.com/channel/UCJUsryI3i0T9KNTQxRJHuRg