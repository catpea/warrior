Visit [Outdoor Bavaria][1] in German and the new bushcraft and survival
channel [Wild Woman Bushcraft][2] in English.

[1]: https://www.youtube.com/channel/UCuQV_7hln2oL_nhfEShubZQ
[2]: https://www.youtube.com/channel/UCuQV_7hln2oL_nhfEShubZQ