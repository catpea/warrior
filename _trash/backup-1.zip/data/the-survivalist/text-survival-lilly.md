"Hi, my name is Lilly! I am a survivalist from Austria and I like to share
my experiences with like minded people." [YouTube Channel][1]

[1]: https://www.youtube.com/channel/UCS4LBgyn1WLSojiQI4aPjtg