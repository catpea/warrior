Primitive technology is a hobby where you build things in the wild
completely from scratch using no modern tools or materials. [Primitive
Technology YouTube Channel][1]

[1]: https://www.youtube.com/channel/UCAL3JXZSzSm8AlZyD3nQdBA