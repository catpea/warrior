[Girl in the Woods Channel][1] (Alaska)

[Emelie's Outdoor Adventures Channel][2] (Sweden, she **eats** an ant)

[Athena Mellor Channel][3] (Mountaineer from United Kingdom)

[1]: https://www.youtube.com/user/alaskagirlinthewoods
[2]: https://www.youtube.com/channel/UCotHWNgPBgUPsbK-XYLZ-fw
[3]: https://www.youtube.com/user/athenajane1