Strength does not reside in having never been broken, but in the courage
required to grow strong in the broken places.