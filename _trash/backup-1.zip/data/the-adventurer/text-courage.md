No matter how dark our origins. No matter where we stand, and where we are
headed. We are each charged with becoming a great being, by growing up, by
growing all the way up.

On a wounded knee, is no way to be free. Wherever we come from,
Authenticity is our candle in the dark.

Carine McCandless, Christopher’s sister, explains a lot more about his
journey.