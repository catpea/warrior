To die having made Something more equal to the centuries Than muscle and
bone, is mostly to shed weakness.