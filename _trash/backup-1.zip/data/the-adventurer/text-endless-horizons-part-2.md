[Christopher Johnson McCandless, aka Alexander Supertramp, aka Alex][1] teaches us important lessons about the unbreakability of the human spirit, the danger of loneliness, and about the nearly irresistible beauty of the call to the wild.

[Jon Krakauer][2] wrote a book about Alex entitled [Into the Wild][3], and there is also a [movie][4].

[1]: https://en.wikipedia.org/wiki/Chris_McCandless
[2]: https://www.audible.com/author/Jon-Krakauer/B000AQ8WPY
[3]: https://www.audible.com/pd/Into-the-Wild-Audiobook/B002V1NYEK
[4]: https://www.youtube.com/watch?v=g7ArZ7VD-QQ