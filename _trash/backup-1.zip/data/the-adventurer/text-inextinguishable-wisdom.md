Our search for wisdom, as well as our climb onto the shoulders of giants,
is just the first part of our story. When we learn to push ourselves to
travel the hardest slopes, our shoulders will become strong enough to
support the countless adventurers that are sure to follow. Long after we
depart, our hard earned wisdom will retain the momentum of our hardest
slopes, to serve as an inextinguishable candle in the dark.